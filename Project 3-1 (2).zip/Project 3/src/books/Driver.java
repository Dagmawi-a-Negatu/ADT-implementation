package books;

import java.util.Scanner;

import myadt.ASet;
import myadt.SetInterface;

public class Driver {
	
	
	public static void main(String[] args) {
		
		
		@SuppressWarnings("resource")
		Scanner kbInput = new Scanner(System.in);
		
		System.out.println("Set type (L for linked , A for Array bases):");
		char type  = kbInput.nextLine().trim().toUpperCase().charAt(0);
		
		System.out.println("Enter a file name");
		String fileName = kbInput.nextLine();
		
		System.out.println("You you like the list reversed (Y/N)");
		char rev  = kbInput.nextLine().trim().toUpperCase().charAt(0);
		boolean reverse = rev == 'Y'? true:false;
		
		if(FileHandler.hasBooks(fileName)) {	
			SetInterface<Novel> books = FileHandler.novelLoader(fileName, type,reverse);
			if(books != null)
				books.printList();
		}else {
			SetInterface<String> strings = FileHandler.stringlLoader(fileName,type,reverse);
			
			if(strings != null)
				strings.printList();
		}
		System.out.println("Program end!");
			
	}

}
