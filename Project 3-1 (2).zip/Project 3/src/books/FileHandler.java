package books;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.NoSuchElementException;
import java.util.Scanner;

import myadt.ASet;
import myadt.LSet;
import myadt.SetInterface;
/**
 * The file handler loads text files in and uses this to generate Novel
 * objects or just strings depending on if books have been detected in the file.
 * @author Dagmawi Negatu
 *
 */

public class FileHandler {
	
	/**
	 * Check the first line of a text file to see if it contains the
	 * value  #Book and if so return true.
	 * @param fileName The name, or file path and name of the file to check.
	 * @return true if the file has #Book as its first line.
	 */
	public static boolean hasBooks(String fileName){
		Scanner fileIn = null;
		boolean hasBooks = false;
		try {
			FileReader file =new FileReader(fileName);
			fileIn = new Scanner(file);
			
			String firstLine = fileIn.nextLine();
			hasBooks = firstLine.equals("#Book");
			
		}catch(FileNotFoundException fnfe) {
			System.err.println("Error cannot find file: " + fileName);
		}catch(NoSuchElementException nex) {
			System.err.println("Error, file empty");
		}finally {
			if(fileIn != null)
				fileIn.close();
		}
			
		return hasBooks;
	}

	
	/**
	 * Attempt to read a text file in and return an ASet of Novels in.
	 * @param fileName The file name from which to load the novels
	 * @param type 'A' for ASet, 'L' for LSet.
	 * @param rev if true the set will be reversed.
	 * @return An ASet containing Novel objects or null in the case of an exception.
	 */
	public static SetInterface<Novel> novelLoader(String fileName, char type, boolean rev) {
		
		SetInterface<Novel> set =  type == 'A' ?new ASet<Novel>(rev) : new LSet<Novel>(rev);
		
		Scanner fileIn = null;
		boolean error = false;
		
		try {
			FileReader file =new FileReader(fileName);
			fileIn = new Scanner(file);
			
			while(fileIn.hasNext()) {
				String next = fileIn.nextLine();
				if(next.equals("#Book")) {
					String title = fileIn.nextLine();
					String author = fileIn.nextLine();
					String genre = fileIn.nextLine();
					int year = Integer.parseInt(fileIn.nextLine());
					
					set.add(new Novel(title,author,genre,year));	
				}
					
			}//end while
			System.out.println("Success " + fileName + " loaded");
		}catch(FileNotFoundException fnfe) {
			System.err.println("Error cannot find file: " + fileName);
			set = null;
		}catch(NumberFormatException nfe) {
			System.err.println("Error, file format invalid");
			set = null;
		}finally {
			if(fileIn != null)
				fileIn.close();
		}
		

			
		return set;
	}
	
	/**
	 * Attempt to read in a text file as Strings and return an ASet of Strings.
	 * Each element of the ASet is a complete line in the input file.
	 * @param fileName The file name to check.
	 * @param type 'A' for ASet, 'L' for LSet.
	 * @param rev if true the set will be reversed.
	 * @return The ASet of Strings or null in the case of an exception.
	 */
	public static SetInterface<String> stringlLoader(String fileName, char type, boolean rev) {
		
		SetInterface<String> set = type == 'A' ? new ASet<String>(rev) : new LSet<String>(rev);
		Scanner fileIn = null;
		
		try {
			FileReader file =new FileReader(fileName);
			fileIn = new Scanner(file);
			
			while(fileIn.hasNext()) {
				String next = fileIn.nextLine();
				
				System.out.print( next.length() > 0 ? next.charAt(0):" ");

				set.add(next);		
			}//end while
			System.out.println("Success " + fileName + " loaded");
		}catch(FileNotFoundException fnfe) {
			System.err.println("Error cannot find file: " + fileName);
			set = null;
		}catch(NumberFormatException nfe) {
			System.err.println("Error, file format invalid");
			set = null;
		}finally {
			if(fileIn != null)
				fileIn.close();
		}
		
		return set;
	}
	
	

}//end class
