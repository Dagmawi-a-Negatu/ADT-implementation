package books;

/**
 * 
 * @author Darwin Bueso Galdamez, Salim Abdullahi
 * 
 * Models a Novel with an title, author, genre and date with getter 
 * and setter methods for each field, an equals, toString and an 
 * implimentation of the Comparable<T\> interface.

 *
 */

public class Novel extends Object implements Comparable<Novel> {
	private String author; // Author of the book
	private int date; // Number of date, not including appendices
	private String title; // Title of the book
	private String genre; // Genre of the book
	
	
	/**
	 * 
	 * Default constructor that assigns default values for the fields.
	 * 
	 * @param title title of the novel.
	 * @param author author of the novel.
	 * @param genre genre the novel was written in.
	 * @param date when the novel was published.
	 */
	public Novel(String title, String author, String genre, int date) {
		this.title = title;
		this.author = author;
		this.genre = genre;
		this.date = date;
	}
	

	/**
	 * Determine the author of the book.
	 * 
	 * @param author the author of this book.
	 */
	
	public String getAuthor() {
		return author;
	}
	
	
	/**
	 * Change the author of the book.
	 * 
	 * @param author  the author of this book.
	 */
	public void setAuthor(String author) {
		this.author = author;
	}
	
	/**
	 * Determine the number of date in a book.
	 * 
	 * @return number of date.
	 */
	
	public int getDate() {
		return date;
	}
	
	/**
	 * Change the number of date in a book.
	 * 
	 * @param date - number of date in the book.
	 */

	public void setDate(int date) {
		this.date = date;
	}
	
	/**
	 * Get the title of the book.
	 * 
	 * @return the title of the book.
	 */

	public String getTitle() {
		return this.title;
	}
	
	/**
	 * Change the title of the book.
	 * 
	 * @param title- the title of this book.
	 */
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	/**
	 * Determine the book's genre.
	 *
	 * @return the genre for this book.
	 */

	public String getGenre() {
		return genre;
	}
	
	/**
	 * Change the genre of the book.
	 * 
	 * @param genre The genre for this book.
	 */

	public void setGenre(String genre) {
		this.genre = genre;
	}
	

	/**
	 * Check that this Novel equals another object or a different or same type. 
	 * Novels are considered equal if they have the same title, author, genre and date.
	 * In all other cases they are considered in equal.
	 * 
	 * @param other - The other object to check.
	 * 
	 * @return true if equal false if not equal.
	 * 
	 */

	public boolean equals(Object other) {
		boolean result = false;
		
		if(other instanceof Novel) {
			Novel otherNovel = (Novel) other;
		
			
			if(this.title.equals(otherNovel.title) && 
					this.author.equals(otherNovel.author) && 
					this.genre.equals(otherNovel.genre) &&  
					this.date  == otherNovel.date)
				result = true;

		}
		return result;
		
		
	}
	
	/**
	 * Compare one novel to another first alphabetically based on Author name, 
	 * then on date, then on Title and finally on Genre. When comparing alphabetically 
	 * we can depend on the normal behavior of the compareTo method of the String class.
	 * 
	 * @param o - The other novel.
	 * 
	 * @return 0 if the novels are equal or the same object reference, > 0 if this novel 
	 * comes before the other, < 0 if the other novel comes before this one.
	 */
	
	@Override
	public int compareTo(Novel o) {
		int compare = this.getAuthor().compareTo(o.getAuthor());
		
		if(compare == 0)
			compare = this.getDate() - o.getDate();
		
		if(compare == 0)
			compare = this.getTitle().compareTo(o.getTitle());
		
		if(compare == 0)
			compare = this.getGenre().compareTo(o.getGenre());

		return compare;
			
	}
	
	/**
	 * Convert this object to a single line String with an output format as shown below:
	 * Nineteen Eighty Four: George Orwell : Dystopian Fiction : 1949.
	 * 
	 * @return A string containing the object state.
	 * 
	 */
	
	public String toString() {
		return this.title + " : " + this.author + " : " + this.genre + " : " + this.date;
	}
}
