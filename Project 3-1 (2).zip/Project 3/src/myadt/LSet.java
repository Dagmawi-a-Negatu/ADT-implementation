package myadt;

import java.util.Iterator;
import java.util.NoSuchElementException;


/**
 * This is a concrete implementation of a Set using Links. 
 * It models the mathematical set abstraction in which the 
 * set must not contain duplicates (objects with a duplicate 
 * state determined by calling the Equals method of each object element) 
 * and that the values in the list must be ordered 
 * (determined using the compareTo method of each object element.)
 * lowest to highest. 
 * NOTE: The with a SET the elements must not be duplicates, 
 * and they must be ordered lowest to highest. CS151, project 2.
 * Note this class MUST 
 * use a generic array! All parameters, fields and local variables have good
 * Set DEFAULT_CAPACITY to 10 for testing purposes
 * @version: April 2023
 * @Author Dagmawi Negatu
 */

public class LSet<R extends Comparable<R>> extends Object implements SetInterface<R>, Iterable<R> {

	/**
	 * The head node of this linked list based set
	 */
	private LSet<R>.Node head;
	
	/**
	 * The count of elements in this linked list
	 */
	private int numElements;
	
	/**
	 * By default the set is not reversed
	 */
	private boolean reversed;

	
	/**
	 * Create an LSet
	 */
	public LSet() {
		this.clear();

	}

	/**
	 * Create an LSet
	 * @param reversed - , if false the Set is ordered lowest to highest,
	 *  if true, it is ordered highest to lowest.
	 */
	
	public LSet(boolean reversed) {
		this();
		this.reversed = reversed;

	}
	
	/**
	 * Constructor that creates a LSet based on the values 
	 * from any class implementing the CollectionInterface.
	 * As this is a Set any duplicate entries
	 * (object references that are the same or objects have the same state)
	 * will be skipped. Note: This constructor must set the initial size
	 * to be the same as the default size(but this will change as items are added).
	 * After calling this method, the capacity of this ASet should be 
	 * the number of elements plus the default capacity.
	 * The collection passed in, should not get modified in by calling this method.
	 * @param collection  - collection that will be used to build this LSet.
	 * If the collection has duplicate elements,
	 * only the first one will be added to the new set.
	 * @param reversed - , if false the Set is ordered lowest to highest, 
	 * if true, it is ordered highest to lowest.
	 * @throws IllegalArgumentExcpetion if passed collection
	 * does not contain real data.
	 */

	public LSet(SetInterface<? extends R> collection, boolean reversed) {
		this();
		// Set the reversed flag based on the parameter
		this.reversed = reversed;

		// Handle exception if the passed in collection is null
		if(collection == null ) {
			throw new IllegalArgumentException("Collection does not contain any data");
		}
		
		// If the collection is not an instance of ASet, add the first element
		// (in case of an LSet where we cannot access the first element using the iterator)
		if(collection instanceof ASet == false) {
			if(collection.size() > 0) {
				this.add(collection.get(0));
			}
		}
			
		//In case of ASet add all object
		//Similarly add objects from second element in case of LSet
		for (R object: collection) { 
			this.add(object);

		}
		
		

	}
	
	/**
	 * Clear the set so that the are 0 elements.
	 */
	
	@Override
	public void clear() {
		
		//As head contains first element, set to null
		this.head = null;
		
		//Set the number of object in our ASet to 0, 
		//removing all objects
		this.numElements = 0;
	}
	
	/**
	 * Return true if this set is empty.
	 */

	@Override
	public boolean isEmpty() {
		return (head == null & this.numElements == 0);
	}

	/**
	 * Get the number of elements in this linked list.
	 * The last element in the set will at index size -1
	 * because the first element is at index 0.
	 */
	
	@Override
	public int size() {
		//Start from the head
		Node current = this.head;

		// Traverse the linked list to count the number of elements
		while(current != null){
			current = current.getNextNode();

		}

		// Return the number of elements counted
		return numElements;

	}

	/**
	 * In theory there is no capacity to a linked list,
	 * but we are limited in the use of an integer used for indexing the elements
	 * Specified by: capacity in interface SetInterface<R extends Comparable<R>>
	 * @return The value of Integer.MAX_VALUE which 
	 * is the maximum index supported by an integer.
	 */
	
	@Override
	public int capacity() {

		return (Integer.MAX_VALUE);
	}

	@Override
	public void printList() {
		
		System.out.println(this.toString());
	}

	
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		//Start at the head
		Node current = head;
		
		//Initialize the number of characters to 1
		int numCharac = 1;
		
		//Append an opening angle bracket to the StringBuilder object
		sb.append("<");
		
		//Iterate over the ASet data array and append 
		//each element to the StringBuilder object
		while (current != null) {
			//Increment the number of characters by 2
			numCharac +=  2;
			//Append the element to the StringBuilder object
			sb.append(current.data);
			//If the number of characters is greater than 94, 
			//append a new line character and reset the number of characters to 0
			if(numCharac > 50 ) {
				sb.append("\n");
				numCharac = 0;
			}
			
			//Append a comma and space if it's not the last element in the ASet
			if(current.next != null) {
				sb.append(", ");
			}
			
			//Move to the next node
			current = current.next;
			
			
			
			
			
		}
		//Append a closing angle bracket to the StringBuilder object
		sb.append(">");
		//Return the string representation of the StringBuilder object
		return sb.toString();
	}	


	/**
	 * Get the item at the index position specified
	 * @param x - or null if not object at that index.
	 * @return The element at the index specified.
	 * @throws IndexoutOfBounds if the set is empty
	 * or index is out of range
	 */
	
	@Override
	public R get(int x) {

		// Throw an exception if the set is empty or the index is out of range
		if (isEmpty() || x < 0 || x >= size()) {
			throw new IndexOutOfBoundsException("Set is empty");
		}


		//Traverse the linked list to find the node at the specified index
		Node current = head;
		int index = 0;
		while (current != null) {
			if (index == x) {
				return current.data;
			}
			current = current.next;
			index++;
		}

		// Return null if the index is not found
		return null;
	}
	
	/**
	 * Return the index of the first object in the list which matches this object
	 * @param - object to search for.
	 * @return indicating the objects position in the set, 
	 * -1 if the object does not exist in this LSet
	 * @throws IllegalArgumentException - if the parameter value is null;
	 * 
	 */

	@Override
	public int getIndex(Object input) {

		// Throw an exception if input is null
		if (input == null) {
			throw new IllegalArgumentException("Input cannot be null");
		}

		int index = 0;
		Node currentNode = head; // Assuming head is the first node of the linked list

		// Traverse the linked list and find the first matching object
		while (currentNode != null) {
			if (currentNode.data.equals(input)) {
				return index;
			}
			currentNode = currentNode.next;
			index++;
		}

		// Object not found, return -1
		return -1;
	}

	/**
	 * Add an item in order where it needs to go within the set
	 * add in interface SetInterface<R extends Comparable<R>>
	 * @param element - The element to add.
	 * @return true if successful false if not.
	 */
	
	@Override
	public boolean add(R e) {
		boolean added = false;
		
		if(!this.contains(e)) {
			// Otherwise, insert the element in order and set added flag to true	
			insertInOrder(e);
			added = true;
		}
		return (added);

	}

	
	
	/**
	 * A private method to insert an item in the correct position within the set.
	 * Does not check if item is already in the list.
	 * @param element - The element to add.
	 */
	
	private void insertInOrder(R element) {
		
		// //Throw an exception if the passed-in object is null
		if(element == null) {
			throw new IllegalArgumentException("Object passed does not contain real data");
		}

		
		//Create a new node containing the element to add
		//And set other fields
		Node nodeToAdd = new Node(element);
		Node current = head;
		Node previous = null;
		
		
		//A reversed SetInterface
		//The R element is less than than the element at that position make space
		//Insert moving all objects to the right side of the collection
		//else continue looping	
		if(isReversed()) {
			while (current != null && element.compareTo(current.data) < 0) {
				previous = current;
				current = current.next;
			}
		}
		
		//A non reversed SetInterface
		//The R element is greater than than the element at that position make space
		//Insert moving all objects to the right side of the collection
		//else continue looping
		else if(!isReversed()) {
			while (current != null && element.compareTo(current.data)> 0) {
				previous = current;
				current = current.next;
			}
		}

		
		//If first element inserted
		//make the correct position changes to reflect additional elements
		if (previous == null) {
			head = nodeToAdd;
		} else {
			previous.next = nodeToAdd;
		}

		nodeToAdd.next = current;
			

		//Update number of elements LSet or ASet
		this.numElements++;

		
	}

	
	/**
	 * Add all items from another SetInterface implementation
	 * to this set provided the generic types are the same.
	 * @param collection - Another SetInterface implementation
	 * either an ASet or an LSet.
	 * @return true if this list is changed because of this call,
	 * false otherwise.
	 * @throws  thorws IllegalArgumentException
	 * if collection is null or contains null
	 */
	@Override
	public boolean addAll(SetInterface<? extends R> collection) {

		//Check collection is null
		if (collection == null) {
	        throw new IllegalArgumentException("Collection cannot be null");
	    }

	    //LSet or ASet not modified
		boolean changed = false;
		
		//Collection LSet, add first element separately
		if(collection instanceof LSet) {
			if(collection.size() > 1) {
				if(add(collection.get(0))) {
					changed = true;
				}
			}
		}
		
		// Loop through all elements in collection and add them to this set
		for (R element : collection) {
	        if (element == null) {
	            throw new
	            IllegalArgumentException("Elements in collection cannot be null");
	        }
	        
	     // Add the element to this set
	        if (add(element)) {
	            changed = true;
	        }
	    }
		
		//Whether LSet modified
	    return changed;
	
	}

	/**
	 * Determine if a specific object is in the list.
	 * This is determined by not just the memory location of input,
	 * but also by checking if they have the same state.
	 * contains in interface SetInterface<R extends Comparable<R>>
	 * @param input - object to search for
	 * @return true if the object is in the list, false otherwise.
	 * @throws IllegalArgumentException -
	 * generated if the object to search for is null.
	 */
	@Override
	public boolean contains(Object o) {

		// Create an iterator to traverse through the elements of this set
		Iterator<R> it = this.iterator();

		// Check if the specified object is null
		if(o == null) {
			throw new
			IllegalArgumentException("Object does not contain real data");
		}
		
		//Set is not empty, 
		//check if the first element matches the specified object
		if(this.numElements > 0) {
			if(this.get(0).equals(o)) {
				return (true);
			}
		}
		// Traverse through the remaining elements of the set
		//and check if they match the specified object
		while (it.hasNext())
			if (it.next().equals(o))
				return true;
		// The specified object is not found in the set
		return false;
	}

	/**
	 * Returns true if this list contains all of the elements
	 * of the specified SetInterface instance. 
	 * If the specified collection is also a list,
	 * this method returns true if it is a sublist of this list.
	 * Specified by: containsAll in interface 
	 * SetInterface<R extends Comparable<R>>
	 * @param collection to be checked for containment in this list.
	 * @return true if this list contains
	 * all the elements of the specified collection
	 */
	@Override
	public boolean containsAll(SetInterface<? extends R> c) {
		// Iterate over each element of the collection
		for (Object e : c)
			//this set does not contain the current element
			if (!contains(e))
				return false;
		//LSet contains all in the specified collection
		return true;
	}
	/**
	 * Removes the specified element from this list if it is present.
	 * (This List will not contain the element once the call returns.
	 * Specified by: remove in interface 
	 * SetInterface<R extends Comparable<R>>
	 * @param o - The object to find and remove.
	 * @return true if this list contained the element 
	 * (or equivalently, if this list changed as a result of the call).
	 * @throws IllegalArgumentException - if the specified object is null.
	 */
	@Override
	public boolean remove(Object o) {
		//Object is null
		if (o == null) {
			throw new IllegalArgumentException("Object cannot be null");
		}

		boolean removed = false;
		Node current = head;
		Node prev = null;
		// Traverse through the linked list until the end
		//or the specified element is found
		while (current != null) {
			if (current.data.equals(o)) {
				if (prev == null) {
					// If the element is at the head, 
					//set the next node as the new head
					head = current.next;
				} 
				// If the element is not at the head, 
				//set the next node as the previous node's next
				else {
					prev.next = current.next;
				}
				removed = true;
				this.numElements--;
				break;
			}
			// Move to the next node
			prev = current;
			current = current.next;
		}

		// Return whether the specified element was successfully removed
		return removed;


	}


	/**
	 * Removes from this list all of its elements that are contained
	 * in the specified CollectionInterface instance.
	 * If the specified collection is also a set,
	 * this operation effectively modifies this list so that its
	 * value is the asymmetric set difference of the two lists.
	 * Specified by removeAll in interface
	 * SetInterface<R extends Comparable<R>>
	 * @param collection - collection containing elements to be removed from this List.
	 * NOTE!! Take care if the collection passed in is the same reference as this object,
	 * you will encounter a concurrent modification problem,
	 * that is you will be removing elements from the very object
	 * being looped though leading to inconsistencies.
	 * In this special case, shallow copy the object (by calling a constructor)
	 * so that the object references are not one and the same.
	 */
	@Override
	public boolean removeAll(SetInterface<? extends R> collection) {

		// Throw exception if collection is null
	    if (collection == null) {
	        throw new IllegalArgumentException("Collection cannot be null");
	    }

	    boolean changed = false;// Flag to track if any elements were removed

	    // Remove the first element of the collection
	    //if it is present in this set
	    if (collection.size() > 0) {
	        if (remove(collection.get(0))) {
	            changed = true;
	        }
	    }

	    // Remove all remaining elements of the collection
	    for (R element : collection) {
	        // Throw exception if element is null
	        if (element == null) {
	            throw new IllegalArgumentException("Elements in collection cannot be null");
	        }
	        if (remove(element)) {
	            changed = true;
	        }
	    }

	    // Check if all elements from the collection were removed from this set
	    if (this.containsAll(collection)) {
	        this.clear();
	    }

	    return changed;// Return true if element removed, false otherwise
	}

	
	/**
	 * Retains only the elements in this list that are contained
	 * in the specified CollectionInterface instance.
	 * In other words, removes from this list all of its elements
	 * that are not contained in the specified collection.
	 * If the specified collection is also an AList,
	 * this operation effectively modifies this AList so that its
	 * value is the intersection of the two lists.
	 * retainAll in interface SetInterface<R extends Comparable<R>>
	 * @param collection - collection containing
	 * elements to be retained in this list.
	 * @return true if this list is changed
	 *  because of this call, false otherwise.
	 * @throws IllegalArgumentException - if collection is null.
	 */
	@Override
	public boolean retainAll(SetInterface<? extends R> collection) {

		// Throw exception if specified collection is null
		if (collection == null) {
			throw new IllegalArgumentException("Collection cannot be null");
		}

		boolean modified = false;
		R removable = null;

		// Check if this list has any elements and
		//if the first element is not contained in the specified collection
		if (this.numElements > 0 && !collection.contains(get(0))) {
			removable = get(0); // Mark the first element as removable
			modified = true; // Mark the list as modified
		}

		// Iterate through the list and remove elements that are
		//not contained in the specified collection
		Iterator<R> iterator = iterator();
		while (iterator.hasNext()) {
			R element = iterator.next();
			if (!collection.contains(element)) {
				remove(element);
				modified = true; // Mark the list as modified
			}
		}

		//If the first element was marked as removable, remove it from the list
		if (removable != null) {
			remove(removable);
		}

		return modified;
	}


	/**
	 * Compares the specified object with this AList (or sub class) for equality.
	 * Returns true if the specified object is also a MyList instance, 
	 * the two ALists have the same size, and every member of the specified list
	 * is contained in this list (or equivalently, every member of this list is
	 * contained in the specified list). This definition ensures that the equals
	 * method works properly across different implementations of the AList interface.
	 * Overrides: equals in class Object
	 * @param other - object to be compared for equality with this set.
	 * @return true if the specified object is equal to this AList, false otherwise.
	 */
	public boolean equals(Object other) {

		boolean isEqual = false;
		// Check if the two objects are the same instance
		if(this == other) {
			return (true);
		}
		if(other instanceof ASet) { //Check if are instances of each other
			@SuppressWarnings("unchecked")
			SetInterface<? extends R> temp = (SetInterface<? extends R>) other;
			//Check their size and elements
			if(this.size() == temp.size() && this.containsAll(temp)) 
				isEqual = true;
			//If both sets are empty, they are the same as well
			else if(isEmpty() && temp.isEmpty()) 
				isEqual = true;
		}
		return isEqual;


	}
	
	/**
	 * This function will return true if
	 * this set is reversed and false if it is not reversed.
	 * isReversed in interface SetInterface<R extends Comparable<R>>
	 * 
	 * @return True if reversed, false if not reversed
	 */

	@Override
	public boolean isReversed() {

		return this.reversed;
	}

	/**
	 * Reverse the order of the set. If the set is in
	 * a lowest to highest (non reversed) state, 
	 * this function will put it into highest to lowest state,
	 * and reverse the order of the items in the set. 
	 * At that point adding more items would maintain
	 * the highest to lowest order of the set.
	 * If the set is in a highest to lowest (reversed) state state,
	 * calling this method would order the elements lowest to highest.
	 * Adding additional elements would then maintain the lowest to highest order.
	 */
	
	@Override
	public void reverse() {

		// Initialize temporary node variable and start and end nodes
		Node temp = null;
		Node start = head;
		Node end = null;

		// Traverse through the linked list to reverse it
		while (start != null) {
			// Store the next node to traverse through the linked list
			temp = start.next;
			// Set the next pointer of the current node to the previous node
			start.next = end;
			// Set the end node as the current node
			end = start;
			// Set the start node as the next node to traverse through
			start = temp;
		}

		// Set the head of the linked list as the last node of the original linked list
		this.head = end;

		// Toggle the reversed flag to indicate the state of the ASet
		if(isReversed()) {
			this.reversed = false;
		}else {
			this.reversed = true;
		}
	}

	/**
	 * Return an iterator for this LSet
	 * Specified by: iterator in interface Iterable<R extends Comparable<R>>
	 * @return A new iterator instance for the LSet.
	 */
	
	@Override
	public Iterator<R> iterator() {

		return new LIterator();
	}

	/**
	 * An iterator implementation to get each successive item in the Iterator
	 */

	private class LIterator implements Iterator<R>{
		/**
		 * The current node being iterated though
		 */
		private LSet<R>.Node current;

		/**
		 * Construct an LIterator.
		 */
		private LIterator() {
			current = head;

		}

		/**
		 * Is there another element to access in this linked list?
		 */
		
		public boolean hasNext() {
			if (current == null) {
				return false;
			}

			return current.next != null;

		}

		/**
		 * Get the next element in the linked list if one exists.
		 */
		public R next() {	
			if (!hasNext())
				throw new NoSuchElementException("There is no next item to get an element from");
			else {
				current = current.next;
				return current.data;
			}
		}

	}

	/**
	 * A node of the linked list.
	 */
	
	private class Node{

		/**
		 * A the data stored by the node
		 */
		private R data;
		/**
		 * A pointer to the next node
		 */
		private Node next;

		/**
		 * Construct a node with this data.
		 * @param data - The data for the node.
		 */
		private Node(R data) {
			this.data = data;
			this.next = null;
		}

		/**
		 * Construct a node.
		 * @param data data - The data the node will store.
		 * @param nextNode nextNode - A pointer to the next node.
		 */
		
		private Node(R data, LSet<R>.Node nextNode) {
			this.data = data;
			this.next = nextNode;

		}
		
		/**
		 * Get the data of this node.
		 * @return The data
		 */

		@SuppressWarnings("unused")
		private R getData() {
			return this.data;

		}
		
		/**
		 * Set the date for the node.
		 * @param data - The data to go in the node.
		 */

		@SuppressWarnings("unused")
		private void setData(R data) {
			this.data = data;

		}

		/**
		 * Get the next node this node points to.
		 * @return The next node.
		 */
		public LSet<R>.Node getNextNode(){
			return this.next;

		}

		/**
		 * Set the next node this node points to.
		 * @param nextNode - The next node.
		 */
		
		@SuppressWarnings("unused")
		public void setNextNode(LSet<R>.Node nextNode) {
			this.next = nextNode;
		}

	
	

	}

}
