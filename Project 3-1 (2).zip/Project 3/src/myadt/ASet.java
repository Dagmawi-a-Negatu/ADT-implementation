package myadt;


import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;


/**
 * This is a concrete implementation of a Set using generic arrays.
 * It models the mathematical set abstraction in which the set must
 * not contain duplicates (objects with a duplicate state determined
 * by calling the Equals method of each object element)
 * and that the values in the set must be ordered (determined using
 * the compareTo method of each object element.)
 * lowest to highest. NOTE: The with a SET the elements must not be
 * duplicates, and they must be ordered lowest
 * to highest. CS151, project 2.
 * Note this class MUST use a generic array! 
 * All parameters, fields and local
 * variables should have good, descriptive names.
 * You will need fields not indicated here for the program to function.
 * Set DEFAULT_CAPACITY to 10 for testing purposes
 * @author Dagmawi Negatu
 * @version: April 2023
 */


public class ASet<R extends Comparable<R>> implements SetInterface <R> {

	/**
	 * Array of objects that contains elements of type R.
	 */
	private R[] data;

	/**
	 * Default capacity for data set to 10.
	 */
	private static final int DEFAULT_CAPACITY = 10;

	/**
	 * Field to check if ASet is empty,
	 * true for empty, false for not empty.
	 */
	private boolean empty = true;

	/**
	 * Number of elements contained in data.
	 */
	private int numElements;

	/**
	 * Capacity of data, changes as we add elements to the data array.
	 */
	private int capacity;
	

	/**
	 * True if the items in this set are reversed (high to low)
	 * false if the items in this set are ordered low to high.
	 */
	private boolean reversed;

	/**
	 * Constructor that creates a set of some initial size.
	 * This constructor sets the initial size to be the same as the default size.
	 * This constructor calls the other one to complete its job.
	 */
	public ASet() {
		this(DEFAULT_CAPACITY);
		this.numElements = 0;
	}

	/**

	This is a constructor method for the ASet class,
	which creates a set with an initial capacity.
	@param capacity - the initial capacity of the set to be created
	@throws IllegalArgumentException if capacity is less than or equal to zero
	*/
	public ASet(int capacity) {

		// Check if the capacity is valid i.e., not zero or negative
		if (capacity <= 0 ) {
			throw new IllegalArgumentException
			("Capacity cannot be zero or negative");
		}

		// Set the initial capacity of the set and initialize the other fields
		this.capacity = capacity;
		numElements = 0;
		this.empty = true;

		// Instantiate a new array of elements of type R, 
		//which is a Comparable, with the given capacity
		@SuppressWarnings("unchecked")
		R[] list = (R[]) new Comparable [capacity];

		// Set the data field of the ASet object to the newly created array
		this.data = list;
	}

	/**
	 * Constructor that creates a ASet based on the values from
	 * any class implementing the CollectionInterface.
	 * As this is a Set any duplicate entries
	 * (object references that are the same or objects have the same state)
	 * will be skipped. Note: This constructor must set the initial size
	 * to be the same as the default size
	 * (but this will change as items are added).
	 *  After calling this method, the capacity of this ASet should be
	 * the number of elements plus the default capacity.
	 * The collection passed in, should not get modified in
	 * by calling this method.
	 * @param collection collection that will be used to build this ASet.
	 * If the collection has duplicate elements,
	 * only the first one will be added to the new set.
	 * @throws IllegalArgumentException if the given collection is null
	 */

	public ASet(SetInterface<R> collection, boolean reversed) {
		

		//Default constructor with the reversed flag ASet object
		this(reversed);

		// Throw an exception collection is null
		if (collection == null) {
			throw new IllegalArgumentException("The given collection does not contain any data");
		}

		// Collection an instance of LSet, add the first element ASet object
		if (collection instanceof LSet && collection.size() > 0) {
			this.add(collection.get(0));
		}

		// Iterate through collection adding each element ASet object
		for (R object : collection) {
		this.add(object);
		}
		
		
	}

	/**
	 * Constructor that creates a set of some initial size.
	 * Constructor sets the initial size to be the same as the default size.
	 * This constructor must call the other one to complete its job.
	 * @param reversed
	 */

	public ASet(boolean reversed) {
		
		//Default constructor initialize ASet object
		this();

		//reversed flag to parameter
		this.reversed = reversed;
		
	}

	/**
	 * Inner class that iterates though a Collection of
	 * its outer class via the methods next() and hasNext().
	 * @throws IllegalArgumentException if the given collection null
	 */
	public class AIterator implements Iterator<R> {

		// The current element index
		private int index;

		/**

		This is a constructor method for the AIterator class that creates
		a new iterator and sets the index to the first element in the set.
		*/
		public AIterator() {
			index = 0;
		}
		/**

		This method checks if there is another element in the set after the current element.
		@return true if there is another element, false otherwise
		*/
		@Override
		public boolean hasNext() {
			return index < ASet.this.size();
		}
		/**

		This method retrieves the next element in the set.
		If there are no more elements, a NoSuchElementException is thrown.
		@return the next element in the set
		@throws NoSuchElementException if there are no more elements in the set
		*/
		@Override
		public R next() {
			if (!hasNext()) {
				throw new NoSuchElementException("No more elements in the set");
			}
			R object = ASet.this.data[index];
			index++;
			return object;
		}

	}


	/**

	This method clears all data from the ASet object by setting
	all elements to null and resetting the size to zero.
	*/
	public void clear() {
		// Set the empty flag to true
		this.empty = true;

		// Iterate through the ASet and set each element to null
		for (int i = 0; i < this.numElements; i++) {
			this.data[i] = null;
		}

		// Set the number of elements to zero
		this.numElements = 0;
	}

	/**
	 * Determines if this set contains no elements.
	 * @return - true if this set contains no elements, false otherwise.
	 */
	public boolean isEmpty() {
		return (this.data == null || this.empty);
	}

	/**
	 * Returns the number of elements in this set (its cardinality).
	 * @return - the number of elements in this set (its cardinality).
	 */
	public int size() {
		return (this.numElements);
	}

	/**
	 * Returns the capacity of this Set.
	 * The capacity is the number of available elements for storing object
	 * including the used and unused elements.
	 * The capacity will be subject to change as items are added beyond
	 * the original default capacity.
	 * @return - The number of elements available for storing objects.
	 */
	public int capacity() {
		return (this.capacity);
	}

	/**
	 * A method of the Iterable interface.
	 * Will return an iterator of a generic type corresponding with this class.
	 * Instance of our AIterator
	 */
	@Override
	public Iterator<R> iterator() {

		return new AIterator();
	}


	/**
	 * Adds the specified element to this set if it is not already present.
	 * More formally, adds the specified element e to this set 
	 * if the set contains no element e2 such that
	 * e != null && e.equals(e2). If this set already contains the element,
	 * the call leaves the set unchanged
	 * and returns false. In combination with the restriction on constructors,
	 * this ensures that sets never
	 *  contain duplicate elements.
	 * @param object - object to be added to the end of this set
	 * @return true if the set did not already contain the element.
	 * @throws IllegalArgumentException if the object is null
	 */
	@Override
	public boolean add(R object) {

		// Set added flag to false
		boolean added = false;

		// Handle exception if object is null
		if(object == null) {
			throw new IllegalArgumentException("Object passed contains no real data");
		}

		// Check if the ASet already contains this object
		if(contains(object)) {
			return false;
		}

		// Add the object in the correct order in the ASet
		if(this.insertInOrder(object)){
			this.numElements++;
			this.empty = false;
			added = true;
		}

		return added;
		
	}


	/**

	This method returns true if the set contains the specified element.
	@param o the element to check for in the set
	@return true if the set contains the element, false otherwise
	@throws IllegalArgumentException if the input object is null
	*/
	@Override
	public boolean contains(Object o) {
		boolean result = false;

		// Throw an exception if the input object is null
		if(o == null) {
			throw new IllegalArgumentException("Input object is null");
		}

		// Iterate through all elements in the ASet
		for(Object e : data) {
			// Compare all ASet objects with other object
			if(e != null && o != null) {
				if(e.equals(o)) { 
					result = true;
					break;
				}
			}
		}
	return result;
	
	}


	/**
	 * Returns true if this set contains all of the elements of the specified CollectionInterface instance.
	 * If the specified collection is also a set, this method returns true if it is a subset of this ASet.
	 * @param collection - collection to be checked for containment in this set.
	 * @return: true if this ASet contains all the elements of the specified collection.
	 */

	@Override
	public boolean containsAll(SetInterface<? extends R> c) {
		// TODO Auto-generated method stub
		// If the collection is an instance of ASet, then it is already contained within this set.
		if (c instanceof ASet) {
			return true;
		}

		// Iterates through each object in the collection and checks if it is contained within this set.
		for (R object : c) {
			if (!this.contains(object)) {
			return false;
			}
		}

		// All objects are contained within this set.
		return true;
		
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * (This set will not contain the element once the call returns.)
	 * @param o - object to remove from the collection.
	 * @return Removes the specified element from this set if it is present.
	 * (This set will not contain the element once the call returns.)
	 * @throws IllegalArgumentExcpetion if object is null
	 */

	@Override
	public boolean remove(Object o) {

		boolean removed = false; // Field tracks if our object has been removed from ASet.
		int removedIndex = -1; // Index of removed element.

		// Throw exception if the input object is null.
		if (o == null) {
			throw new IllegalArgumentException("Cannot remove null object from ASet.");
		}

		// Iterate our ASet and remove object.
		for (int i = 0; i < this.numElements; i++) {
			if (o.equals(data[i])) { // Check if the object is in ASet.
				this.data[i] = null; // Set the object at index i as null.
				this.numElements--; // Decrease the number of elements.
				removed = true; // Set removed flag as true.
				removedIndex = i; // Store the index of removed element.
				break;
			}
		}

		if (removed) { // If the object is removed from ASet.
			// Move our null element to the right hand side.
			for (int k = removedIndex; k < this.numElements; k++) {
				this.data[k] = this.data[k + 1];
			}
		}

		return removed;
	}
	

	/**
	 * From the index supplied, push every item in the array up.
	 * by one leaving a gap (null value) at the index.
	 * @param index the position at which to leave a gap.
	 * @throws IndexOutOfBoundsException if index is out of range
	 * (index < 0 || index > size())
	 */
	private void makeSpace(int index) {

		//Field deceleration
		R currentObject = this.data[index];
		R nextObject = null;
		
		if((index < 0 || index > size())) {
			throw new IndexOutOfBoundsException("Index passed is out of range");
		}

		//Iterate over until the end of our ASet and make space
		for (int i = index; i < this.data.length -1; i++) {
			nextObject = this.data[i+1];
			this.data[i+1] = currentObject;
			currentObject = nextObject;
		}

		this.data[index] = null;

	}

	/**
	 * Adds all of the elements in the specified SetInterface instance to this set in order.
	 * Any duplicate entries in the set are ignored.
	 * If the specified collection is also a SetInterface implementation
	 * with an inner type that is the same
	 * (or one of its sub classes),  the addAll operation effectively modifies
	 * this set so that adds those things in the second set.
	 * The behavior of this operation is undefined if the specified collection
	 *  is modified while the operation is in progress.
	 * @param collection - collection containing elements to be added to this set.
	 * @return true if this set is changed because of this call, false otherwise
	 * @throws IllegalArgumentException if the collection null or contains null.
	 */
	@Override
	public boolean addAll(SetInterface<? extends R> c) {

		//Throw an IllegalArgumentException if the collection is null
		if (c == null) {
			throw new IllegalArgumentException("Collection cannot be null");
		}

		//Variable to keep track of whether the set has been changed
		boolean changed = false;

		//Add elements from a ListSet
		if(c instanceof LSet) {
			//If the ListSet has more than one element, only add the first element
			if(c.size() > 1) {
				if(add(c.get(0))) {
					changed = true;
				}
			}
		}

		//Iterate over the elements in the collection and add them to the ASet
		for (R element : c) {
			//Throw an IllegalArgumentException if the element is null
			if (element == null) {
				throw new IllegalArgumentException("Elements in collection cannot be null");
			}
			//If the element is added to the ASet, set the changed variable to true
			if (add(element)) {
				changed = true;
			}
		}

		//Return whether the ASet has been changed
		return changed;
	}

	/**
	 * Removes from this set all of its elements that are contained
	 * in the specified CollectionInterface instance.
	 * If the specified collection is also a set,
	 * this operation effectively modifies this set so that its value
	 * is the asymmetric set difference of the two sets.
	 * @param c - object to remove from the collection.
	 * @return true if this set contained the element.
	 * (or equivalently, if this set changed as a result of the call).
	 * @throws IllegalArgumentException if the specified collection is null
	 * or contains a null element.
	 */

	@Override
	public boolean removeAll(SetInterface<? extends R> c) {
		// TODO Auto-generated method stub
		//No object has been removed.
		boolean removed = false;

		//Handle Exception if our specified collection is null.
		if(c == null) {
			throw new IllegalArgumentException("Collection data passed is null");
		}

		//Iterate over our specified collection and remove desired object from our ASet.
		
			for(R object: c) {
				if(this.contains(object)) {
					this.remove(object);
					removed = true;
				}
			}
		

		//If removed reassign our key fields.
		if(removed) {
			this.numElements = 0;
			this.empty = true;
		}

		return removed;

	}

	/**
	 * removes from this set all of its elements that are 
	 * not contained in the specified collection.
	 * If the specified collection is also an SetInterface implementation,
	 * this operation effectively modifies this ASet so that
	 * its value is the intersection of the two SetInterface implementations.
	 * @param collection - A SetInterface implementation containing
	 * elements to be retained in this ASet.
	 * @return true if this set contained the element
	 * (or equivalently, if this set changed as a result of the call).
	 * @throws throws IllegalArgumentException if object is null
	 */

	public boolean retainAll(SetInterface<? extends R> collection) {

		// Field declaration for tracking whether the set has been modified
		boolean modified = false;

		// Handle the case when the specified collection is null
		if(collection == null) {
			throw new IllegalArgumentException("Specified collection cannot be null");
		}

		// Iterate over the elements of the set and remove any element
		//that is not in the specified collection
		for(int i = 0; i < this.numElements; i++) {
			if(!collection.contains(get(i))) {
				this.remove(this.data[i]);
					modified = true;
					i--;
			}
		}

		return modified;
	}

	/**
	 * Get a reference to the element at the location specified.
	 * @param o - object to remove from the collection.
	 * @return true if this set contained the element
	 * (or equivalently, if this set changed as a result of the call).
	 * @throws IndexOutOfBoundsExcpetion if index out of range
	 * or our ASet instance does not contain real data.
	 */
	@Override
	public R get(int x) throws NoSuchElementException {

		//Handle exception if the passed in parameter value
		//results in Index out of bounds exception.
		if (x >= this.numElements || isEmpty()) {
			throw new IndexOutOfBoundsException("Location specified is out of range or ASet is empty.");

		}

		return this.data[x];
	}

	/**
	 * Resizes the array so that new elements are able to be stored within it.
	 * @param size new size of the array
	 */
	protected void ensureCapacity(int size) {

		if (size <= capacity) {
			//No need to resize if the current capacity is sufficient.
			return;
		}

		//Resize the internal array.
		this.capacity = size;
		R[] newData = Arrays.copyOf(this.data, size);
		this.data = newData;
			

	}

	/**
	 * Return the index of the first object in the set which matches this object
	 * @param input - object to search for.
	 * @return index indicating the objects position in the set, -1 if the object does not exist in this ASet.
	 */
	@SuppressWarnings("unchecked")
	public int getIndex(Object input) {

		//Field Deceleration
		int index = -1;
		R temp = null;


		//Handle exception if the passed in object is null.
		if(input == null) {
			throw new IllegalArgumentException("The parameter value is null;");
		}

		//Iterate over our object ASet and find the index of our R element.
		for(int i = 0; i < this.numElements;i++) {
			temp = (R) input;

			if (this.get(i).equals(temp)) {
				return (i);
			}
		}


		return index;
	}

	/**
	 * A private helper method to insert an element at the specified location In the set.
	 * It must make space for the new element by moving subsequent elements to the right by one,
	 * then insert the new element.
	 * If the addition of the new element will exceed the capacity of the underlying array,
	 * we must ensure there is capacity @see ensureCapacity(int size).
	 * @param element - The set element (item) to insert
	 * @param index - The index at which to insert the item in the set
	 */

	private void insertAt(R element, int index) {

		//Ensures the capacity of our ASet object
		if(this.capacity == this.numElements) {
			this.ensureCapacity(this.capacity*2);
		}

		//make space for our object if that index is filled by R element
		if(this.data[index] != null) {
			this.makeSpace(index);
		}

		//Reassign our ASet at specified index with the specified R element
		this.data[index] = element;

	}

	/**
	 * A private method to insert an item in the correct position within the set.
	 * @param element
	 * @return true if the item was added, false if not.
	 */

	private boolean insertInOrder(R element) {

		//Set flag false because R element has not been added
		boolean insertInOrder = true;

		insertAt(element, this.numElements);

		//If object is the first element added just add it to index 0.
		if(this.numElements == 0) {
			this.data[0] = element;
			return true;
		}


		//Iterate over ASet and add object in the correct order.
		for (int i = 0; i < this.capacity -1 ;i++) {

			//If our ASet object is null just add it here instead of making space.
			if(this.data[i] == null) {
				this.data[i] = element;
				return true;

			}
			//A reversed SetInterface
			//The R element is less than than the element at that position make space
			//Insert moving all objects to the right side of the collection
			//else continue looping
			if(!this.isReversed()) { 
				if (this.data[i].compareTo(element) > 0) {
					insertAt(element, i);
					return true;
				}
				
			//A non reversed SetInterface
			//The R element is greater than than the element at that position make space
			//Insert moving all objects to the right side of the collection
			//else continue looping
			}else if(this.isReversed()) {
				if(this.data[i].compareTo(element) < 0) {
					insertAt(element, i);
					return(true);
				}
			}

		}


		return insertInOrder;

	}


	/**
	 * Compares the specified object with this ASet (or sub class) for equality.
	 * Returns true if the specified object is also a SetInterface instance,
	 * the two ASet have the same size,
	 * and every member of the specified ASet is contained in this set
	 * (or equivalently, every member of this ASet is contained in the specified ASet).
	 * This definition ensures that the equals method works properly across different
	 * implementations of the SetInterface interface.
	 * @param Check that this Novel equals another object or a different or same type.
	 * Novels are considered equal if they have the same title, author, genre and date.
	 * In all other cases they are considdered in equal.
	 * @return true if equal false if not equal.
	 */

	@SuppressWarnings("unchecked")
	@Override
	public boolean equals(Object other) {
//		
		if(other == null) {
			return (false);
		}
		
		//SetInterface that is ASet or LSet
		SetInterface<? extends R> temp = (SetInterface<? extends R>) other;
		boolean result = false;
		
		//Is LSet, temp As LSet
		if(other instanceof LSet ) { //Check if are instances of each other
			 temp = (LSet<R>) other;
		//Is ASet, temp as ASet
		}else {
			temp = (ASet<R>) other;
		}
		
		//Check their size and elements
		if(this.size() == temp.size() && this.containsAll(temp)) 
				result = true;
		//If both sets empty, they are equal
		else if(isEmpty() && temp.isEmpty()) 
			result = true;
		
		return result;

	}

	/**
	 * Returns a string with elements if the set listed in the format <e, e, e>.
	 * No more than 95 characters will be printed on a single line.
	 * @return a string representing the state of this set.
	 */
	@Override
	public String toString() {

		//Create a new StringBuilder object
		StringBuilder sb = new StringBuilder(); 
		
		//Append an opening angle bracket to the StringBuilder object
		sb.append("<");
		
		//Initialize the number of characters to 1
		int numCharac = 1;

		//Iterate over the ASet data array and append 
		//each element to the StringBuilder object
		for(int i = 0; i < this.numElements;i++) {
			
			//Append the element to the StringBuilder object
			sb.append(this.data[i]);
			
			//Append a comma and space if it's not the last element in the ASet
			if((i+1) < this.numElements) {
				sb.append(", ");
			}
			
			//Increment the number of characters by 2
			numCharac += 2;

			//If the number of characters is greater than 94, 
			//append a new line character and reset the number of characters to 0
			if(numCharac > 94 ) {
				sb.append("\n");
				numCharac = 0;
			}
			
		}

		//Append a closing angle bracket to the StringBuilder object
		sb.append(">");

		//Return the string representation of the StringBuilder object
		return sb.toString();

	}

	/**
	 *  Reverse the order of the set. If the set is in a lowest to highest (non reversed) state,
	 *  this function will put it into highest to lowest state, and reverse the order of the items in the set.
	 *  At that point adding more items would maintain the highest to lowest order of the set.
	 *  If the set is in a highest to lowest (reversed) state state,
	 *  calling this method would order the elements lowest to highest.
	 *  Adding additional elements would then maintain the lowest to highest order.
	 */

	@Override
	public void reverse() {
		@SuppressWarnings("unchecked")
		
		// Create a new array to store the reversed elements
		R[] reversed = (R[]) new Comparable [capacity];
		
		// Traverse the original array in reverse order and
		//copy its elements to the new array
		int index = 0;

		for(int i = this.numElements -1; i > -1; i--) {
			reversed[index] = this.data[i];
			index ++;
			
		}
		
		// Set the data array to the reversed array
		this.data = reversed;
		
		// Toggle the reversed flag to indicate the state of the ASet
		if(isReversed()) {
			this.reversed = false;
		}else {
			this.reversed = true;
		}

	}

	@Override
	public boolean isReversed() {
		
		return this.reversed;
	}


	/**
	 * Display all the items in this set using System.out.println().
	 */
	@Override
	public void printList() {
		System.out.println(this.toString());
	}

}
