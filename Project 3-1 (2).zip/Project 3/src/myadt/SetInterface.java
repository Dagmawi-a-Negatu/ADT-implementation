package myadt;

import java.util.Iterator;

/**
 * This is an interface which models a set the can contain 0 to many unique Objects in sequence and be dynamically sized. 
 * This interface is loosely based on Java's own SetIntface with ideas taken from other Java Collections interfaces.

 * CS151, progect 2.
 * @author William Kreahling
 * @author Andrew Scott
 * @version 10/22/2021
 */
public interface SetInterface <R extends Comparable<R>> extends Iterable<R> {

    /**
     * Adds the specified element to this list. Where the element e gets added is 
     * decided by the specific implementation of this CollectionInterface.
     * Returns true when the item was added to the list and false if it was not.
     * @param e element to be added to this list
     * @return true if the item was added to the list.
     * @throws IllegalArgumentException if the element to be added is null.
     */
    public boolean add( R e);
    
     /**
     * Clears all data from this list.
     */
    public void clear();
    
    /**
     * Determine if a specific object is in the list.
     * @param o object to search for
     * @return true if the object is in the list, false otherwise.
     * @throws IllegalArgumentException generated if the object to search for is null.
     */
    public boolean contains(Object o);
    
    /**
     * Returns true if this list contains all of the elements of the specified SetInterface instance.
     *  If the specified collection is also a list, this method returns true if it is a sublist of this
     *  list.
     * @param c collection to be checked for containment in this list.
     * @return true if this list contains all the elements of the specified collection.
     * @throws IllegalArgumentException If the specified collection is null or contains any null
     * elements.
     */
    public boolean containsAll(SetInterface<? extends R> c);

    /**
     * Determine if this list contains no elements.
     * @return true if this list contains no elements, false otherwise. 
     */
    public boolean isEmpty();
    
    /**
     * Removes the specified element from this list if it is present. This List will not contain
     * the element once the call returns.
     * @param o The object to find and remove.
     * @return true if this list contained the element (or equivalently, if this list changed as a
     * result of the call). 
     * @throws IllegalArgumentException if the specified object is null.
     */
    public boolean remove(Object o);
    
    /**
     * Adds all of the elements in the specified collection to this list. Where the elements get added is 
     * up to the specific implementation.
     * If the specified collection is also an instance od ListInterface, the addAll
     * operation effectively modifies this list so that its value is the union of the two lists. The
     * behavior of this operation is undefined if the specified collection is modified while the
     * operation is in progress.
     * @param c collection containing elements to be added to this list.
     * @return true if this list is changed because of this call, false otherwise.
     * @throws IllegalArgumentException if collection is null or contains a null element.
     */
    public boolean addAll(SetInterface<? extends R> c);

    /**
     * Removes from this list all of its elements that are contained in the specified collection.
     * If the specified collection is also a list, this operation effectively
     * modifies this list so that its value is the asymmetric set difference of the two lists.
     * @param c collection containing elements to be removed from this list.
     * @return true if this list is changed because of this call, false otherwise.
     * @throws IllegalArgumentException if the specified collection is null.
     */
    public boolean removeAll(SetInterface<? extends R> c);
    
    /**
     * Retains only the elements in this list that are contained in the specified collection.
     * In other words, removes from this list all of its elements that are
     * not contained in the specified collection. If the specified collection is also a list, this
     * operation effectively modifies this set so that its value is the intersection of the two
     * sets.
     * @param c collection containing elements to be retained in this list.
     * @return true if this set is changed because of this call, false otherwise.
     * @throws IllegalArgumentException if the specified collection is null.
     */
    public boolean retainAll(SetInterface<? extends R> c);
    
    
    /**
     * Gets the object at the index x.
     * @param x or null if not object at that index.
     * @return The object or null if no object at that index.
     */
    public R get(int x);
    
    /**
     * Returns the number of elements in this list (its cardinality).
     * @return the number of elements in this list (itss cardinality).
     */
    public int size();
    
    /**
     * Returns the capacity of this Set. The capacity is the number of available elements for
     * storing objects.  Depending on the implementation the capacity may be dynamic and grow as needed.
     * @return The number of elements available for storing objects.
     */
    public int capacity();
    
    
	/**
	 * Helper method which checks for the null elements in the list.
	 * @param list is the collection of elements
	 * @return false if the list does not contain any null elements, true otherwise.
	 */
	public default boolean containsNull(SetInterface <?> list){
		boolean containsNull = false;
		Iterator<?> iterator = list.iterator();
		
		/*Iterates through the collection and checks if any elements contains null*/
		while(iterator.hasNext()){
			containsNull = iterator.next() == null;
			if(containsNull){
				break;     
			}
		}
		return containsNull;
	}
	
	//NEW METHODS FOR THE INTERFACE BELOW HERE, SOME OF THESE WERE IN
	//PROJECT 1 BUT NOT THE INTERFACE. THE REVERSE AND ISREVERSED METHODS
	//ARE NEW.
	
    /**
     * Return the index  of the first object in the list which matches this object
     * @param input object to search for.
     * @return index indicating the objects position in the set, -1 if the object does not exist
     * in this AList.
     * @throws IllegalArgumentException if the parameter value is null;
     */
    public int getIndex(Object input);
    
    
    /**
     * Print each item in the set by calling the toString of each
     * element in the list and outputting the result to the console.
     */
    public void printList();
    
    
    /**Reverse the order of the set. If the set is in a lowest to highest (non reversed) state, 
     * this function will put it into highest to lowest state, and reverse the order of the
     * items in the set. At that point adding more items would maintain the highest to lowest
     * order of the set. If the set is in a highest to lowest (reversed) state state, calling this 
     * method would order the elements lowest to highest. Adding additional elements would then 
     * maintain the lowest to highest order. **/
    public void reverse();
    
    
    /**
     * This function will return true if this set is reversed and false if it is not reversed.
     * @return True if reversed, false if not reversed.
     */
    public boolean isReversed();
    
    
    //Not shown but inherited from object will be equals and toString for which implimentations are needed.

}//end 
