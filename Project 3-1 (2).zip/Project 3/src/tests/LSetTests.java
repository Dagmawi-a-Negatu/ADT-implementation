package tests;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

/*
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
*/

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import books.FileHandler;
import books.Novel;
import myadt.ASet;
import myadt.LSet;
import myadt.SetInterface;


@DisplayName("JUnit 5, Unit tests for myadt.ASet.Java")
public class LSetTests {
	
	//Fixtures for all tests
	private static LSet<? extends Comparable<?>> f1= null;/**Any type goes in this LSet**/
	private static LSet<? extends Comparable<?>> f2 = null;/**Any type goes in this LSet**/
	private static LSet<Novel> f3 = null;

	private static LSet<String> f4 = null;/**LSet for storing Strings**/
	private static LSet<String> f5 = null;/**Another LSet for storing Strings**/
	

	
	private static Novel n1 = null;/**Novel fixture for 1984**/
	private static Novel n2 = null;/**Novel fixture for Tale of two cities**/
	private static Novel n3 = null;/**Novel fixture for Concrete Rose**/
	private static Novel n4 = null;/**Novel fixture for To Kill a Mocking Bird**/

	//Fixtures for each test
	private LSet<String> tf1 = null;/**LSet of strings**/
	private LSet<Novel> tf2 = null;/**LSet of novels**/
	//private LSet<Integer> tf3 = null;/**LSet for integers**/
	private LSet<String> tf4 = null;/**LSet for Strings**/
	private LSet<Novel> tf5 = null;/**LSet for novels**/
	//private LSet<Novel> tf6 = null;/**LSet for novels**/
	private LSet<String> tf7 = null;/**Another LSet of Strings**/
	
	private static LSet<String> r1 = null;/**Will hold a reversed order list**/
	private LSet<String> r2 = null;/**A reversed set of Strings**/
	private LSet<Novel>  r3 = null;/**A reversed set of Novels**/

	/**Sup these fixtures before any test in this suite runs**/
	@BeforeAll
	public static void beforeClass() {

		//default empty set
		f1 = new LSet<>();
		
		//Another empty set.
		f2 = new LSet<>();
		
		//An empty set to store novels
		f3 = new LSet<Novel>();
		
		
		//Set of one item
		f4 = new LSet<>();
		f4.add("Unprecidented");
		
		//Set of 11 items, should have capacity of 20.
		f5 = new LSet<>();
		f5.add("One");
		f5.add("Two");
		f5.add("Three");
		f5.add("Four");
		f5.add("Five");
		f5.add("Six");
		f5.add("Seven");
		f5.add("Eight");
		f5.add("Nine");
		f5.add("Ten");
		f5.add("Eleven");
		
		
		
		

		
		n1 = new Novel("1984","George Orwell","Dystopian future",1949);
		n2 = new Novel("Tale of Two Cities","Charles Dikens", "Historical Fiction",1859);
		n3 = new Novel("Concrete Rose","Angie Thomas","Adult contemporary",2021);
		n4 = new Novel("To Kill A Mocking Bird","Harper Lee","Historical Fiction",1960);	
	}
	
	/**Set up these fixtures before each test in the test suite runs**/
	@BeforeEach
	public void before() {
		//Empty sets to play with
		tf1 = new LSet<>();
		tf2 = new LSet<>();
		//tf3 = new LSet<>();
		tf5 = new LSet<>();
		
		//Set of String objects
		tf4 = new LSet<>();
		tf4.add("Hershey's");
		tf4.add("Reese's");
		tf4.add("Snickers");
		tf4.add("Kit Kat");
		tf4.add("Twix");
		tf4.add("3 Musketeers");
		tf4.add("Milky Way");
		tf4.add("Almond Joy");
		tf4.add("Baby Ruth");
		tf4.add("Payday");
		
		//With three novels.
		tf5.add(n1);
		tf5.add(n2);
		tf5.add(n3);
		
		//Set with a null entry
		//tf6 = new LSet<>();
		
		//Set of 3 items added out of sequence, should be lowest to highest
		tf7 = new LSet<>(false);
		tf7.add("Alpha");
		tf7.add("Delta");
		tf7.add("Beta");
		
		
		r1 = new LSet<>(true);//A reversed set, true reverses
		r1.add("One");
		r1.add("Two");
		r1.add("Three");
		r1.add("Four");
		r1.add("Five");
		r1.add("Six");
		r1.add("Seven");
		r1.add("Eight");
		r1.add("Nine");
		r1.add("Ten");
		r1.add("Eleven");
		
		//Reversed set of Strings
		r2 = new LSet<>(true);
		r2.add("Alpha");
		r2.add("Beta");
		r2.add("Delta");
		
		//Set of novels reverse order, should be highest to lowest
		r3= new LSet<>(true);
		r3.add(n1);
		r3.add(n2);
		r3.add(n3);
		
	}//end before
	

	
	//#####################
	//Constructor tests
	//####################
	
	/**Tests for the default constructor of the ASet class**/
	@Nested
	@DisplayName("Test Constructors of ASet class")
	public class TestDefaultConstructor{


		/**Test the default constructor produces an initial size of 0**/
		@Test
		public void testDefaultConstructorSize() {
			//Description, expected, actual
			assertEquals(0, f1.size(), "The default size is zero");
		}

		
		/**Test the default constructor produces an empty set**/
		@Test
		public void testDefaultConstructorIsEmpty() {
			assertTrue( f1.isEmpty(),"Thet ASet is Empty");
		}
		
	}//end class
	
	@Nested
	@DisplayName("Test the capacity and size")
	public class TestCapacityAndSize{
		
		/**Test the constructor with a capacity creates size 0, when supplied an int of 20**/
		@Test
		public void testInitialSize0() {
			assertEquals( 0 ,f2.size(), "Create an LSet of initial size should be 0" );
		}
		
		
		/**Test the default capacity of the default constructor is 10**/
		@Test
		public void testDefaultConstructorCapacity() {
			assertEquals(Integer.MAX_VALUE, f1.capacity(), 
					      "The default capaciity is Integer.MAX_VALUE");
		}
		
		/**Test the initial  size 0, when supplied an int of 20**/
		@Test
		public void testInitialCapacity() {
			assertEquals(Integer.MAX_VALUE ,f2.capacity(),
					    "Create an LSet of capacity should be Integer.MAX_VALUE" );
		}
		
		
		/**Test the constructor with a capacity when 11 items are added, it shoulsd be 
		 * Integer,MAX_VALUE**/
		@Test
		public void testCapacityAfter11Added() {
			assertEquals( Integer.MAX_VALUE ,f5.capacity(), 
					    "The capacity of LSet f5 shoud be Integer.MAX_VALUE after 11 items added");
		}
		
		
		/**Test the constructor with a capacity when 11 items are added, it shoulsd be 
		 * Integer,MAX_VALUE**/
		@Test
		public void testSizeAfter11Added() {
			assertEquals( 11 ,f5.size(), 
					  "The size of LSet f5 shoud be Integer.MAX_VALUE after 11 items added" );
		}
	
	}//end TestCapacityConstructor
	
	
	@Nested
	@DisplayName("Test the constructor that receives a SetInterface")
	public class TestSetInterfaceConstructor{

		/**
		 * Test the SetInterface receiving constructor throws an IllegalArgumentException
		 *  when passed an ASet containing null.
		 */
		@Test
		public void testSetInterfaceContstructorReceivesNull() {
			try {
				ASet<?> temp = new ASet<>(null,false);
				fail("Constructing an ASet(null) throws an IllegalArgumentException, cannot "+
				      "pass null.");
				temp.clear();
			}
			catch(IllegalArgumentException iae) {
				assertTrue(true,"Constructing an ASet(0) throws an IllegalArgumentException, "+
			                    "cannot pass null.");
			}
		}
		
		
		/**
		 * Test the SetInterface receiving constructor can receive an empty ASet resulting in an empty set with a default capacity.
		 */
		@Test
		public void testSetInterfaceConstructorReceivesEmptyCollection() {
			SetInterface<?> empty = new ASet<>();
			ASet<?> temp = new ASet<>(empty,false);
			//Three asserts are ok here as this function is really testing the ASet(CollectionsInterface) constructor.
			assertEquals(0, temp.size(), "Passing an empty SetInterface to the constructor results "+
			                              "in a zero sized ASet.");
			assertEquals(10,temp.capacity(),"Passing an empty SetInterface to the constructor results"+
			                                " in a default capacity.");
			assertTrue(temp.isEmpty(),"Passing an empty SetInterface to the constructor leves the"+
			                          " set empty.");
			
		}
		
		
		/**
		 * Test the SetInterface constructor when receiving an ASet of 3 elements. 
		 */
		@Test
		public void testSetInterfaceConstructorReceivesCollectionOf3(){
			ASet<String> temp = new ASet<>(tf7,false);
			assertEquals(3,temp.size(), "Passing a SetInterface of 3 elements to the constructor "+ 
			                             "results in a size of 3.");
			assertEquals(10,temp.capacity(), "Passing a SetInterface of 3 elements to the constructor "+
			                               "results in a default capacity.");
			assertFalse(temp.isEmpty(), "Passing a SetInterface of 3 elements to the constructor"+
			                             " leves the set not empty.");	
		}
		
		/**
		 * Test the SetInterface constructor when receiving an ASet of Eleven items.
		 */
		@Test
		public void testCollectionsConstructorReceivesCollectionOf11(){
			ASet<String> temp = new ASet<>(f5,false);
			assertEquals(11,temp.size(), "Passing a SetInterface of 11 elements to the constructor results in a size of 11.");
			assertEquals(20,temp.capacity(), "Passing a SetInterface of 11 elements to the "+
			                             "constructor results in a  capacity double that of the initial capacity.");
			assertFalse(temp.isEmpty(), "Passing a SetInterface of 11 elements to the constructor"+
			                            " leves the set not empty.");	
		}
	
	}//end testConstructors
	
	
	
	/**A nested test suite for the add function**/
	@Nested
	@DisplayName("Test for the add method")
	public class TestAdd{
		
		/**Test adding one valid element to an empty set tf2**/
		@Test
		public void testAddOneElement() {
			tf2.add(n1);
			assertEquals(1, tf2.size(), "Adding a novel to the ASet increses count to 1.");
			assertEquals(Integer.MAX_VALUE, tf2.capacity(), 
					"Adding a novel to the ASet keeps capacity at default.");	
		}
		
		/**Test adding three elements to an empty set tf2**/
		@Test
		public void testAddThreElements() {
			tf2.add(n1);
			tf2.add(n2);
			tf2.add(n3);
			assertEquals(3, tf2.size(),"Adding three Novels to the ASet increses count to 1.");
			assertEquals( Integer.MAX_VALUE, tf2.capacity(), 
					"Adding three Novels to the ASet keeps capacity at default.");	
		}
		  
		/**Test that duplicates cannot be added to a set**/
		@Test
		public void testAddDuplicates() {
			tf2.add(n1);
			tf2.add(  new Novel("1984","George Orwell","Dystopian future",1949));
			tf2.add(n1);
			assertEquals(1, tf2.size(),"Adding the same novel 3 times to an empty set gives a size of 1).");	
		}//end test
		
		/**Test adding an 11th item to a set of 10 items increases the capacity to 20 (double the 
		 * default capacity of 10)**/
		@Test
		public void testAddEleventhIncreasesCapacity() {	
			tf4.add("Butterfinger");
			assertEquals(11,tf4.size(),"Adding eleventh element to the ASet increses count to 11.");
			assertEquals(Integer.MAX_VALUE, tf4.capacity(),
					"Adding eleventh to the ASet doubles the capacity to 20.");	
		}//end test
		
		/**Test adding null to a Set causes an IllegalArgumentException to be thrown**/
		@Test
		public void testAddNull() {
			try {
				tf1.add(null);
				fail("Adding null to an ASet should throw an Illegal ArgumentException.");
			}catch(IllegalArgumentException ex) {
				assertTrue(true, "Adding null to an ASet should throw an Illegal ArgumentException.");
			}catch(Exception e) {
				fail("Adding null to an ASet should throw an Illegal ArgumentException, not other types.");
			}
		}//end test
	}//end test Add
	
	
	

	
	
	
		
	/**A nested test suite for the get function**/
	@Nested
	@DisplayName("Test for the get method")
	public class TestGet{
		
		/**Test get(0) with empty set results in an IndexOutOfBoundsException**/
		@Test 
		public void testGetWithEmptyset() {
			try {
				tf1.get(0);
				fail("Attempting to get an element from an empty set should result in "+
				   "IndexOutOfBoundsException.");
			}catch(IndexOutOfBoundsException ex) {
				assertTrue(true,"Attempting to get an element from an empty set should result in "+ 
			                   "IndexOutOfBoundsException.");
			}catch(Exception e) {
				fail("Attempting to get an element from an empty set should result in "+
			         "IndexOutOfBoundsException, not other types.");
			}
		}
		
		/**Test get(-1) results in an IndexOutOfBoundsException**/
		@Test
		public void testGetWithNegative() {
			try {
				f5.get(-1);
				fail("Attempting to get an element at a negetive index should result in "+
				       "IndexOutOfBoundsException.");
			}catch(IndexOutOfBoundsException ex) {
				assertTrue(true,"Attempting to get an element at a negative indes should result "+
			              "in IndexOutOfBoundsException.");
			}catch(Exception e) {
				fail("Attempting to get an element at a negative indes should result in "+
			          "IndexOutOfBoundsException, not other types.");
			}
		}
		
		/**Test getting the first element of set f5 is "Eight"**/
		@Test
		public void testGetFirst() {
			assertEquals("Eight", f5.get(0), "The first element of fixture f5 is \"Eight\".");	
		}
		
		/**Test getting the last element of set f5 is "Two"**/
		@Test
		public void testGetLastElement() {
			assertEquals("Two", f5.get(10), "The last element of fixture f5 is \"Two\".");	
		}
		
		/**Attempting to get an eleement at an index beyond that of the last element results in an
		 * IndexOutOfBoundsException.
		 */
		@Test
		public void testGetOutOfBounds() {
			try {
				f5.get(f5.size());
				fail("Attempting to get an element at an index beyond the last element should result "+
				      "in IndexOutOfBoundsException.");
			}catch(IndexOutOfBoundsException ex) {
				assertTrue(true,"Attempting to get an element at an index beyond the last element"+
			        " should result in IndexOutOfBoundsException.");
			}catch(Exception e) {
				fail("Attempting to get an element at an index beyond the last element should "+
			        "result in IndexOutOfBoundsException, not other types.");
			}
		}
	}//end testGet
	
	/**Test the getIndex method for what works and what fails**/
	@Nested
	@DisplayName("Test the getIndex(Object) method")
	public class TestGetIndex {
		
		/**Test getIndex by passing a null value, it should throw an IllegalArgumentException**/
		@Test
		public void testNullValue() {
			boolean result = false;
			try {
				int idx = f5.getIndex(null);
				idx = idx+1;//do something with idx to stop warning about not being used.
			}catch(IllegalArgumentException iae) {	
				result = true;
			}catch(Exception e) {
				result = false;
			}
			
			assertTrue(result,
					"When calling get with a null value an IllegalArgumentException is thrown");
		}//end test
		
		/**Test that getIndex returns -1 when object not in the set**/
		@Test
		public void testWithObjectNotInList() {
		   assertEquals(-1,f5.getIndex("ABC"),"Calling getIndex with object not in set returns -1");
		}
		
		/**Test getting the first item in a set**/
		@Test
		public void testGetIndexFirst() {
			 assertEquals(0,f5.getIndex("Eight"),"Calling f5.getIndex(\"Eight\") returns 0 ");
		}
		
		/**Test getting the last item in a set**/
		@Test
		public void testGetIndexLast() {
			 assertEquals(10,f5.getIndex("Two"),"Calling f5.getIndex(\"Six\") returns 10 ");
		}
		
		
		/**Test getting the item in a set**/
		@Test
		public void testGetIndex() {
			 assertEquals(1,f5.getIndex("Eleven"),"Calling f5.getIndex(\"Eleven\") returns 1 ");
		}
		
		/**Test getIndex on an empty list returns -1**/
		@Test
		public void testGetEmtyList() {
			assertEquals(-1,tf1.getIndex("Legs"),"GetIndex on an emptyList returns -1");
		}
		
		
		
	}//end TestGetIndex
		

	
	/**A nested test suite for the clear function**/
	@Nested
	@DisplayName("Test for the clear method")
	public class TestClear{
	
		/**Test that fixture tf4 is cleared, size should be 0.**/
		@Test
		public void testClear() {
			tf4.clear();
			assertEquals(0,tf4.size() , "Fixture tf4 is cleared, size should be 0");	
		}
		
		/**Test that clear had no effect on the capacity of the underlying array**/
		@Test
		public void testClearOnCapacity() {
			tf4.add("Butterfinger");//should double capacity of ft4
			int origCap = tf4.capacity();
			tf4.clear();
			assertEquals(origCap, tf4.capacity(),"Clear should have no effect on capacity, "
					                           + "tf4 should have a capacity of 20" );	
		}
		
		/**Test clearing an already empty set changes the size to zero**/
		@Test
		public void testClearEmptyset() {
			f1.clear();
			assertEquals(f1.size(),0, "Clearing an allready empty set results in a zero "
					                 + "sized ASet.");
		}
	}//end TestClear

	
	/**A nested test suite for the isEmpty method**/
	@Nested
	@DisplayName("Test for the isEmpy method")
	public class TestIsEmpty{
		
		/**Test a new set with no elements added is empty**/
		@Test 
		public void testIsEmptyEmptyset() {
			assertTrue( f1.isEmpty(), "A new set with no elements added is empty");
		}
		
		
		/**Test a set with one item added is not empty**/
		@Test
		public void testIsEmptyWithOneElement() {
			f3.add(new Novel("Ulyssees","James Joyce","Modernist Novel",1922));
			assertFalse(f3.isEmpty(),"A set with  one element added is not empty");
		}
		
		/**Test a set with elements added is not empty**/
		@Test 
		public void testIsEmptyPopulatedset() {
			assertFalse( f4.isEmpty(),"A set with elements added is not empty");
		}
		
		/**Test a cleared set is empty**/
		@Test 
		public void testClearWithIsEmpty() {
			tf4.clear();
			assertTrue( tf4.isEmpty(), "A cleared set is empty");
		}
	}//end testIsEmpty
	
	
	//###############
	//#TEST EQUALS
	//###############
	
	/**A nested test suite for equals method**/
	@Nested
	@DisplayName("Test for the equals method")
	public class TestEquals{
		
		/**Test fixture tf4 is equal to itself**/
		@Test
		public void testEqualsSameReference() {
			assertTrue( tf4.equals(tf4), "TestEquals: The same reference is considdered equal");
		}
		
		/**Test that two distinct sets, with differing elements of the same class and state are 
		 * equal**/
		@Test 
		public void testEqualsSameState(){
			ASet<String> tmp = new ASet<>();
			tmp.add("Alpha");
			tmp.add("Beta");
			tmp.add("Delta");
			assertTrue( tf7.equals(tmp), "TestEquals: The same state is considdered equal");
		}
		
		/**Test that two distinct sets where the only the last element differs is not considered 
		 * equal**/
		@Test 
		public void testEqualsDifferentState(){
			ASet<String> tmp = new ASet<>();
			tmp.add("Alpha");
			tmp.add("Beta");
			tmp.add("Eta");
			assertFalse( tf4.equals(tmp),
					"TestEquals: Two similar sets with differing last elements are not equal.");
		}
		
		/**Test that two distinct sets where the only the first element differs is not 
		 * considered equal**/
		@Test 
		public void testEqualsDifferentStateAgain(){
			ASet<String> tmp = new ASet<>();
			tmp.add("Omega");
			tmp.add("Beta");
			tmp.add("Delta");
			assertFalse( tf4.equals(tmp),
					"TestEquals: Two similar sets with differing first elements are not equal");
		}
		
		/**Test that two empty set are considered equal**/
		@Test
		public void testEqualsTwoEmptyConsidderedEqual() {
			SetInterface<?> tmp = new ASet<>();
			assertTrue( tf1.equals(tmp),"TestEquals: Two empty CollectionInterfaces are equal");
		}
		
		/**Test that equals with a null value will be false.**/
		@Test
		public void testEqualsWithNull() {
			try {
				
				assertEquals(false, tf4.equals(null),"Test equals with null value, it should be false.");
			}catch(Exception e) {
				fail("Test equals with null value, it should return false and not thow an exception.");
			}
				
		}
		
	}//end TestEquals
	
	
	
	/**A nested test suite for addAll method**/
	@Nested
	@DisplayName("Test for the addAll method")
	public class TestAddAll{
		
		/**Adding three items to a set of ten should yield 14 items**/
		@Test
		public void testAddAllSize() {
			tf4.addAll(tf7);		
			assertEquals(13,tf4.size(),"Adding three items to a set of ten should yield 13 items");		
		}
		
		/**Adding a set to itself should have no effect and should return false**/
		@Test
		public void testAddAllSelf() {
		   assertFalse(tf4.addAll(tf4),
				   "A set cannot add to iself this would cause duplicates, add all returns false");
		}
		
		/**Adding a set to itself should have no effect **/
		@Test
		public void testAddAllSelfSideEffects() {
			int initialSize = tf4.size();
			tf4.addAll(tf4);
			int afterSize = tf4.size();
		   assertEquals(initialSize , afterSize, 
				   "Adding a set to itself has no side effects on size.");
		}
		
		
		/**Adding &lt;"Alpha", "Beta", "Delta"&gt; to fixture tf4 should store alpha at index 2, Beta 
		 * at index 4  and Delta at index 5**/
		@Test
		public void testAddAllContainsInOrder() {
			tf4.addAll(tf7);	
			tf4.printList();
			boolean result = tf4.get(2).equals("Alpha") &&
							 tf4.get(4).equals("Beta") &&
							 tf4.get(5).equals("Delta");
		
			assertTrue(result, "Adding \"Alpha\", \"Beta\", and \"Delta\" to tf4 all should be "+
							 "present at indexes 2,4, and 5 (respectively) in set tf4.");		
		}
		
		/**Attempting to addAll with null value to a set results in an IllegalArgumentException.**/
		@Test
		public void testAddAllNull(){
			try {
				tf1.addAll(null);
				fail("AddAll(null) to an ASet should throw an Illegal ArgumentException.");
			}catch(IllegalArgumentException ex) {
				assertTrue(true,"AddAll(null) to an ASet should throw an Illegal ArgumentException.");
			}catch(Exception e) {
				fail("AddAll(null) to an ASet should throw an Illegal ArgumentException, not other types.");
				
			}
				
		}
		

	}//end TestAddAll
	
	
	/**A nested test suite for the contains method**/
	@Nested
	@DisplayName("Test for the contains method")
	public class TestContains{
	
		/**Test that contains can find an item first in the set**/
		@Test
		public void testContainsFirstInset() {
			String first = tf4.get(0);
			
			assertTrue( tf4.contains( first), "Fixture tf4 should contain \""+ first + "\".");		
		}
		
		
		/**Test that contains can find an item last in the set**/
		@Test
		public void testContainsLastInset() {
			String last = tf4.get(tf4.size()-1);
			assertTrue( tf4.contains( last), "Fixture tf4 should contain \""+ last+ "\".");		
		}
		
		/** Passing null to containsAll should result in an IllegalArgumentException. */
		@Test
		public void testContainsWithNull() {
			try {
				tf4.contains(null);
				fail("Test contains with null value, it should throw an Illegal ArgumentException.");
			}catch(IllegalArgumentException ex) {
				assertTrue(true,"Test contains with null value, it should throw an Illegal "+
						"ArgumentException.");
			}catch(Exception e) {
				fail("Test contains with null value, it should throw an Illegal ArgumentException"+
			        ", not other types.");
				
			}
		}
		
		/**Test contains with an absent reference and object**/
		@Test
		public void testContainsAbsentReference() {	
			assertFalse( tf4.contains( new String("Starburst")),"Fixture tf4 shouldn't"+ 
		               " contain starburst");		
		}
	}//end TestContains

	
	
	
	
	
	/**A nested test suite for the remove method**/
	@Nested
	@DisplayName("Test for the remove method")
	public class TestRemove{
		
		/**Test removal of the first item in the set**/
		@Test 
		public void testRemoveFirst(){
			String toRemove = "3 Musketeers";
			tf4.remove(toRemove);
			assertFalse( tf4.contains(toRemove), "Remove first entry from a set of strings.");
		}
		
		/**Test removal of the last item in the set**/
		@Test 
		public void testRemoveLast(){
			String toRemove ="Twix";
			tf4.remove(toRemove);
			assertFalse( tf4.contains(toRemove), "Remove last entry from a set of strings.");
		}
		
		/**Test removal of an item in the set (not first of last)**/
		@Test 
		public void testRemove(){
			String toRemove ="Kit Kat";
			tf4.remove(toRemove);
			assertFalse( tf4.contains(toRemove), "Remove last entry from a set of strings.");
		}
		
		
		
		/**Test removal of a null value throws an IllegalArgumentException**/
		@Test
		public void testRemoveNull() {
			try {
				tf4.contains(null);
				fail("Test remove with null value, it should throw an Illegal ArgumentException.");
			}catch(IllegalArgumentException ex) {
				assertTrue(true, "Test remove with null value, it should throw an Illegal "+
			          "ArgumentException.");
			}catch(Exception e) {
				fail("Test remove with null value, it should throw an Illegal ArgumentException,"+
			          " not other types.");
				
			}
		}
	}//end testRemove

	
	
	/**A nested test suite for the removeAll method**/
	@Nested
	@DisplayName("Test for the removeAll method")
	public class TestRemoveAll{
		
		/**Test removeAll clears the set for a non empty set**/
		@Test
		public void testRemoveAllClears() {
			tf4.removeAll(tf4);
			assertEquals(0,tf4.size(), "Test removeAll with an object containing all values"+
			                            " in the set, it should be size 0.");
			assertTrue( tf4.isEmpty(), "A tf4 set is empty");
		}//end test
		
		/**
		 * Remove all should remove all objectds from the set that are in an external 
		 * CollectionInterface instance. Equality is determined by the equals method.
		 */
		public void testRemoveAllRemovesSome() {
			ASet<String >tmp = new ASet<>();
			tmp.add("Hershey's");
			tmp.add("Reese's");
			tmp.add("Snickers");
			tmp.add("Kit Kat");
			tmp.add("Twix");
			

			tf4.removeAll(tmp);
			
			
			tf4.add("3 Musketeers");
			tf4.add("Milky Way");
			tf4.add("Almond Joy");
			tf4.add("Baby Ruth");
			tf4.add("Payday");
			assertEquals("Test removal of some, tf4 contains "+
			              "<3 Musketeers, Milky Way, Almond Joy, Baby Ruth, Payday>",
					       "<3 Musketeers, Milky Way, Almond Joy, Baby Ruth, Payday>",
					       tf4.toString());
		}//end test
		
		/**Test removing 10 items from tf4 leaving one**/
		public void testRemoveAll() {
			tf4.add("Skipper");
			
			//Create temp list
			ASet<String> temp = new ASet<String>();
			temp.add("Hershey's");
			temp.add("Reese's");
			temp.add("Snickers");
			temp.add("Kit Kat");
			temp.add("Twix");
			temp.add("3 Musketeers");
			temp.add("Milky Way");
			temp.add("Almond Joy");
			temp.add("Baby Ruth");
			temp.add("Payday");
			tf4.removeAll(temp);//just skippper should be left
			
			assertEquals(1, tf4.size(), "Test removing 10 items from tf4 leaving one.");
		}
		
		/**Test removeAll does not alter the capacity**/
		@Test
		public void testRemoveAllDoesNotAlterCapacity() {
			tf4.add("Skipper");
			int initialCap = tf4.capacity();//should now be more than 10, ideally 20.
			
			//Create temp list
			ASet<String> temp = new ASet<String>();
			temp.add("Hershey's");
			temp.add("Reese's");
			temp.add("Snickers");
			temp.add("Kit Kat");
			temp.add("Twix");
			temp.add("3 Musketeers");
			temp.add("Milky Way");
			temp.add("Almond Joy");
			temp.add("Baby Ruth");
			temp.add("Payday");
			
			tf4.removeAll(temp);//just skippper should be left
			int afterCap = tf4.capacity();
			
			assertEquals(initialCap, afterCap, "removeAll does not alter the capacity");
			
		}//end test
		
		
		/**Test removeAll receiving null throws an IllegalArgumentException.**/
		@Test
		public void testRemoveAllWithNull() {
			try {
				tf4.removeAll(null);
				fail("Test removeAll with null value, it should throw an Illegal "+
				     "ArgumentException.");
			}catch(IllegalArgumentException ex) {
				assertTrue( true, "Test removeAll with null value, it should throw an Illegal"+
			           " ArgumentException.");
			}catch(Exception e) {
				fail("Test removeAll with null value, it should throw an Illegal "+
			          "ArgumentException, not other types.");
				
			}
		}//end test
		
	}//end TestRemovall

	

	
	/**A nested test suite for the containsAll method**/
	@Nested
	@DisplayName("Test for the containsAll method")
	public class TestContainsAll{
	
		/**Test containsAll with a another set with the same object references. 
		 * The items are added to the second set in a different order**/
		@Test 
		public void testContainsAllSameReferencesDifferentOrder() {
			SetInterface<Novel> t3 = new ASet<>();
			t3.add(n3);
			t3.add(n1);
			t3.add(n2);
			assertTrue(tf5.containsAll(t3), "Fixture tf5 containsAll novels of another set "+
			          "with same refereces.");
		}//end test
		
		/**Test containsAll with a another set with the same object references. 
		 * The items are added to the second set in the same order**/
		@Test
		public void testContainsAllSameReferencesSameOrder() {
			SetInterface<Novel> t3 = new ASet<>();
			t3.add(n1);
			t3.add(n2);
			t3.add(n3);
			assertTrue(tf5.containsAll(t3), "Fixture tf5 containsAll another set with same "+
			          "refereces, same order.");
			
			
		}//end test
		
		/**Test containsAll still returns true when all objects of the second set
		 * have the same state as those in the first set (but are different objects)**/
		@Test
		public void testContainsAllDifferentObjectsSameState() {
			SetInterface<Novel> t3 = new ASet<>();
			t3.add(n1);
			t3.add(n2);
			t3.add(n3);
			t3.add( new Novel("1984","George Orwell","Dystopian future",1949));
			t3.add(new Novel("Tale of Two Cities","Charles Dikens", "Historical Fiction",1859));
			t3.add(new Novel("Concrete Rose","Angie Thomas","Adult contemporary" ,2021));
			assertTrue(tf5.containsAll(t3),
					"Fixture tf5 containsAll other set with differnt objects of the same state.");
		}//end test
		
		/**
		 * Test containsAll with two set where only the first one differs.
		 */
		@Test 
		public void testContainsAllFirstDifferent(){
			SetInterface<Novel> t3 = new ASet<>();
			t3.add(n1);
			t3.add(n2);
			t3.add(n3);
			t3.add( new Novel("The Color Purple","Alice Walker","Historical Fiction",1982));
			t3.add(  new Novel("Tale of Two Cities","Charles Dikens", "Historical Fiction",1859));
			t3.add(new Novel("Concrete Rose","Angie Thomas","Adult contemporary" ,2021));
			
			assertFalse( tf5.contains(t3), 
					"Fixture tf5 does not  containAll novels of another set where the first differs");
		}//end test
		
		/**Test the contains all method where by the last element differs in the other set**/
		@Test
		public void testContainsAllLastDifferent() {
			SetInterface<Novel> t3 = new ASet<>();
			t3.add( new Novel("1984","George Orwell","Dystopian future",1949));
			t3.add(new Novel("Tale of Two Cities","Charles Dikens", "Historical Fiction",1859));
			t3.add( new Novel("The Color Purple","Alice Walker","Historical Fiction",1982));
			assertFalse( tf5.contains(t3), "Fixture tf5 does not  containAll novels of another"+
			                               " set where the last differs");
		}//end test
		
		/**
		 * Contains all merely seeks to check if all items in the specified collection (parameter) 
		 * exist in the other set.
		 */
		@Test
		public void testContainsAllSubset() {
			SetInterface<Novel> t3 = new ASet<>();
			t3.add( new Novel("1984","George Orwell","Dystopian future",1949));
			t3.add(new Novel("Tale of Two Cities","Charles Dikens", "Historical Fiction",1859));
			assertTrue( tf5.containsAll(t3), "Fixture tf5 does  containAll novels of another set"+
			                                  " where paramter reference is a subset of tf5");
		}//end test
		
		
		/**Passing a null value to the containsAll function should result in an 
		 * IllegalArgumentException**/
		@Test
		public void testContainsAllNull() {
			try {
				tf4.contains(null);
				fail("Test containsAll with null value, it should throw an Illegal "+
				     "ArgumentException.");
			}catch(IllegalArgumentException ex) {
				assertTrue(true,"Test containsAll with null value, it should throw an "+
			         "Illegal ArgumentException.");
			}catch(Exception e) {
				fail("Test containsAll with null value, it should throw an Illegal "+
			          "ArgumentException, not other types.");
				
			}
		}//end test
	}//end TestContainsAll
	
	

	
	/**A nested test suite for the retainAll method**/
	@Nested
	@DisplayName("Test for the retainAll method")
	public class TestRetainAll{
		
		/**Test retainAll on fixture tf4 with a subset of tf4*/
		@Test
		public void testRetainAll() {
			 ASet<String> tmp = new ASet<>();
			 tmp.add("Hershey's");
			 tmp.add("Snickers");
			 tmp.add("Baby Ruth");
			 tmp.add("Payday");
			 
			 int capacityBefore  =tf4.capacity();
			 tf4.retainAll(tmp);
			 String actual = tf4.toString();
			 String expected =  "<Baby Ruth, Hershey's, Payday, Snickers>";
			 assertEquals( expected,actual,"Test retainAll retaining four items on tf4.");	
			 assertEquals( 4, tf4.size(), "Test retainAll retaining four items on tf4.size.");
			 assertEquals(0, capacityBefore - tf4.capacity(), 
					      "Test retainAll does not affect capacity");
		}//end test
		
		/**Tesr reainAll with tf7 where no match exists, tf7 should be cleared**/
		@Test
		public void testRetainAllNoMatch() {
			 ASet<String> tmp = new ASet<>();
			 tmp.add("Hersheys");
			 tmp.add("Snickers");
			 tmp.add("Baby Ruth");
			 tf7.retainAll(tmp);
			 //Because retain all retains only the items from tmp that are in
			 //tf7, and there are no matches in tf7 from tmp, tf7 should effectively 
			 //be cleared.
			 
			 String actual = tf7.toString();
			 String expected = "<>";
			 assertEquals( expected,actual, "Test retainAll with no match, f3 should be <>.");	
			 assertEquals( 0, tf7.size(), "Test retainAll with no match, f3.size() should be 0");
		}//end test
		
		/**Test retainAll receiving a null value, should throw an IllegalArgumentException**/
		@Test
		public void testRetainAllNull() {
			try {
				tf4.retainAll(null);
				fail("Test retainAll with null value, it should throw an Illegal ArgumentException.");
			}catch(IllegalArgumentException ex) {
				assertTrue(true, "Test retainsAll with null value, it should throw an Illegal"+
			                     " ArgumentException.");
			}catch(Exception e) {
				fail("Test retainAll with null value, it should throw an Illegal "+
			         "ArgumentException, not other types.");
				
			}
		}//end test
	
	}//end testRetainAll
	
	
	
	/**A nested test suite for the toString method**/
	@Nested
	@DisplayName("Test for the toString method")
	public class TestToString{
	
		/**Test toString with an empty set**/
		@Test
		public void testToStringWithEmpty() {
			String actual = f1.toString();
			String expected = "<>";
			assertEquals( expected, actual, "Test toString, a empty set converts to <>");
		}
		
		/**Test toString with a small set of three items**/
		@Test
		public void testToString() {
			String actual = tf7.toString();
			String expected = "<Alpha, Beta, Delta>";
			assertEquals( expected, actual,"Test toString with small set tf7.");
		}
		
		/**Test toString with a small set of one item**/
		@Test
		public void testToStringWithsetOf1() {
			String actual = f4.toString();
			String expected = "<Unprecidented>";
			assertEquals(expected, actual,"Test toString with a set of one f4.");
		}
	}//end testToStrng
	
 
	/**Test the PrintList method of the ASet class**/
	@Nested
	@DisplayName("Tests for the printList method")
	public class TestPrintList{
		
		/**Test an empty list prints without exception**/
		@Test
		public void testEmptySet() {
			try {
				tf1.printList();
				assertTrue(true,"An empty String can print without exception");
			}catch(Exception e) {
				assertTrue(false,"An empty String can print without exception");
			}
		}
		
		/**Test a non empty list prints without exception**/
		@Test
		public void testNonEmptySet() {
			try {
				tf4.printList();
				assertTrue(true,"An empty String can print without exception");
			}catch(Exception e) {
				assertTrue(false, "An empty String can print without exception");
			}
		} 
		
	}

	/**Tests for fileHandling and the correct order of an ASet**/
	@Nested 
	@DisplayName("Tests for fileHandling and the correct order of an ASet")
	public class FileHandlerTests{
		
		@Test
		public void testBookOrder() {
			Novel[] books = new Novel[14];
			
			books[0] = new Novel("The Color Purple" , "Alice Walker" , "US Hisorical Fiction" , 1982);
			books[1] = new Novel("Raven Black","Ann Cleeves", "Crime Fiction", 2006);
			books[2] = new Novel("Harlem Shuffle","Crime Fiction","Colson Whitehead",2021);
			books[3] = new Novel("Jane Eyre","Emily Bronte","Bildungsroman",1847);
			books[4] = new Novel("The Great Gatsby","F. Scott Fitzgerald","Tradegy",1925);
			books[5] = new Novel("Comming Up for Air","George Orwell","Satire",1939);
			books[6] = new Novel ("Nineteen Eighty Four", "George Orwell","Dystopian Fiction", 1939);
			books[7] = new Novel("Animal Farm", "George Orwell" ,"Political Satire" , 1945);
			books[8] = new Novel("To Kill a Mocking Bird", "Harper Lee", "US Historical Fiction", 1960);
			books[9] = new Novel("Ulysses", "James Joyce","Modernist Novel",1904);
			books[10] = new Novel("Don Quixote","Miguel De Cervantes","Novel Fiction", 1605);
			books[11] = new Novel("Invisible Man" , "Ralph Ellison" ,"Social Comentary", 1952);
			books[12] = new Novel("Beloved","Toni Morrison","US Historical Fiction", 1987);
			books[13] = new Novel("White Teeth", "Zadie Smith", "Cultural Fiction", 2000);
			
			SetInterface<Novel>novels = FileHandler.novelLoader("Books1.dat",'L',false);
			int idx = 0;
			boolean passed = true;
			for(Novel book : books) {
				Novel novel = novels.get(idx++);
				if(! novel.equals(book))
					passed = false;
			}//end for
			
			assertTrue(passed,"Book1 loads 14 books ordered first by author, then year, then"+
			                 " title and finally genre,");
		}//end testBookOrder
		
		/**Tests that novels are sorted by author**/
		@Test
		public void testBookAuthor() {
			Novel[] books = new Novel[3];
			boolean passed = true;
			//format of file title, author, genre and year ,same as constructor.
			books[0] = new Novel("AAA","AAA","AAA",2000);
			books[1] = new Novel("AAA","AAB","AAA",2000);
			books[2] = new Novel("AAA","AAC","AAA",2000);
			
			SetInterface<Novel>novels = FileHandler.novelLoader("AuthorTests.dat",'L',false);
			int idx = 0;
			for(Novel book : books) {
				Novel novel = novels.get(idx++);
				if(! novel.equals(book))
					passed = false;
			}//end for
			
			assertTrue(passed,"Novels should sort by author,");
		}

		
		/**Tests that if authors are the same books are sorted by year**/
		@Test
		public void testBookYear() {
			Novel[] books = new Novel[3];
			boolean passed = true;
			//format of file title, author, genre and year ,same as constructor.
			books[0] = new Novel("AAA","AAA","AAA",1999);
			books[1] = new Novel("AAA","AAA","AAA",2000);
			books[2] = new Novel("AAA","AAA","AAA",2001);
			
			SetInterface<Novel>novels = FileHandler.novelLoader("YearTests.dat",'L',false);
			int idx = 0;
			for(Novel book : books) {
				Novel novel = novels.get(idx++);
				if(! novel.equals(book))
					passed = false;
			}//end for
			
			assertTrue(passed,"If authors are the same books are sorted next by yeaer,");
		}
		
		
		/**Tests that if authors and years are the same books are sorted by title**/
		@Test
		public void testBookTitle() {
			Novel[] books = new Novel[3];
			boolean passed = true;
			//format of file title, author, genre and year ,same as constructor.
			books[0] = new Novel("AAA","AAA","AAA",2000);
			books[1] = new Novel("AAB","AAA","AAA",2000);
			books[2] = new Novel("AAC","AAA","AAA",2000);
			
			SetInterface<Novel>novels = FileHandler.novelLoader("TitleTests.dat",'L',false);
			int idx = 0;
			for(Novel book : books) {
				Novel novel = novels.get(idx++);
				if(! novel.equals(book))
					passed = false;
			}//end for
			
			assertTrue(passed,"If authors and year are the same books are sorted next by title,");
		}
		
		
		/**Tests that if author, years and title are the same books are sorted by genre**/
		@Test
		public void testBookGenre() {
			Novel[] books = new Novel[3];
			boolean passed = true;
			//format of file title, author, genre and year ,same as constructor.
			books[0] = new Novel("AAA","AAA","AAA",2000);
			books[1] = new Novel("AAA","AAA","AAB",2000);
			books[2] = new Novel("AAA","AAA","AAC",2000);
			
			SetInterface<Novel>novels = FileHandler.novelLoader("GenreTests.dat",'L',false);
			int idx = 0;
			for(Novel book : books) {
				Novel novel = novels.get(idx++);
				if(! novel.equals(book))
					passed = false;
			}//end for
			
			assertTrue(passed,"If authors, year and title are the same books are sorted next by genre,");
		}

	}//end testSuites
	
	
	/**A nested test suite for the add function**/
	@Nested
	@DisplayName("Test for the Reseved Sets and associated methods")
	public class testReversal{
	
		/**Test reversed field is set correctly for a reversed set**/
		@Test
		public void testIsReversed() {
			assertTrue(r1.isReversed(),"r1.isReversed() returns true");
		}
		
		
		/**Test reversed  field is set correctly for a non reversed set**/
		@Test
		public void testIsNotReversed() {
			r1.reverse();//un reverse a reversed set
			assertFalse(r1.isReversed(),"r1.isReversed() returns false");
		}
		
		
		/**Test that fixture r1 is in reversed order**/
		@Test
		public void testAddOnReversedSet() {
			String[] r1rev ={"Two","Three","Ten","Six","Seven","One",
					         "Nine","Four","Five","Eleven","Eight"};
			
			boolean passed = true;
			
			//An iterator would have been a better more efficient choice here than
			//using get to walk the list each time, but I did not want to make the
			//code dependent on the iterator as students might not have built it yet
			//before wanting to run this test.
			for(int i =0; i < r1rev.length && passed;i++) {
				//If items at indexes do not  equal then test has failed
				if(r1rev[i].equals(r1.get(i))== false) 
					passed = false;
			}//end for
			
			assertTrue(passed,"r1 strings have the order: Two, Three, Ten"+
					  ", Six, Seven, One, Nine, Four, Five, Eleven, Eight");
			
		}//end test
		
		/**Test the reversal of a reversed set**/
		@Test
		public void testReversingReversedSet() {
			String[] r1forward = {"Eight", "Eleven", "Five", "Four", "Nine", "One", 
					              "Seven", "Six", "Ten", "Three", "Two"};
			
			r1.reverse();
		
			
			boolean passed = true;
			
			for(int i =0; i < r1forward.length && passed;i++) {
				//If items at indexes do not  equal then test has failed
				if(r1forward[i].equals(r1.get(i))== false) 
					passed = false;
			}//end for
			
			
			
			assertTrue(passed,"r1 strings have the order "
					+ "Eight, Eleven, Five, Four, Nine, One," +
		              " Seven, Six, Ten, Three, Two");
		              		
			
		}//end test
		
		
		/**Calling reverse should alter the reverse state of the Set**/
		@Test
		public void testReversingSetChangesIsReversed() {
			
			boolean initState = r2.isReversed();
			r2.reverse();
			boolean afterState = r2.isReversed();
			
			assertTrue( initState != afterState && afterState == false, 
					"The reverse() function should change the reversed field. ");		
		}//end test
		
		/**Test the reversal of a non reversed set**/
		@Test
		public void testReversingNonReversedSet() {
			
			tf7.reverse();
			assertTrue( tf7.get(0).equals("Delta") && 
					    tf7.get(1).equals("Beta") && 
					    tf7.get(2).equals("Alpha"), 
					   "Reversing tf7, should be <Delta, Beta, Alpha>");
		}
		
		/**Test the reversal and Back of a non reversed set**/
		@Test
		public void testReversigAndBack() {
			tf7.reverse();
			tf7.reverse();
			assertTrue(tf7.get(0).equals("Alpha") &&
					    tf7.get(1).equals("Beta") && 
					    tf7.get(2).equals("Delta"),
					"Reverse and back tf7 should be <Alpha, Beta, Delta>");
		}//end test
		
		
		/**A reversed set works with containsAll**/
		@Test
		public void containsAllReversedSet() {
			assertTrue( r2.containsAll(tf7),"A reversed set has no effect on containsAll");
		
		}//end test
		
		/**A reversed set works with removeAll**/
		@Test
		public void removeAllReversedSet() {
			r2.removeAll(tf7);
			assertEquals( 0, r2.size(),"A reversed set has no effect on containsAll");
		
		}//end test
		
		
		/**A reversed set works with containsAll**/
		@Test
		public void retainAllReversedSet() {
			LSet<String> tmpSet = new LSet<String>();
			tmpSet.add("Alpha");
			tmpSet.add("Delta");
			r2.retainAll(tmpSet);
			assertEquals( 2, r2.size(), "A reversed set has no effect on containsAll");
		
		}//end test

		/**Test the two parameter constructor with reverse true**/
		@Test
		public void testTwoParamConstructorA() {
			LSet<String> tmpSet = new LSet<String>();
			tmpSet.add("Alpha");
			tmpSet.add("Delta");
			tmpSet.add("Beta");
	
			LSet<String> newSet = new LSet<String>(tmpSet,true);
			
			assertTrue(newSet.get(0).equals("Delta") && 
					   newSet.get(1).equals("Beta")  && 
					   newSet.get(2).equals("Alpha"), 
					   "Assert new set has order <Delta,Beta,Alpha>");
		}//end test
		
		/**Test the two parameter constructor with reverse false**/
		@Test
		public void testTwoParamConstructorB() {
			LSet<String> tmpSet = new LSet<String>();
			tmpSet.add("Alpha");
			tmpSet.add("Delta");
			tmpSet.add("Beta");
	
			LSet<String> newSet = new LSet<String>(tmpSet,false);
			assertTrue( newSet.get(0).equals("Alpha") && 
					     newSet.get(1).equals("Beta") && 
					    newSet.get(2).equals("Delta"), 
					     "Assert new set has order <Alpha,Beta,Delta>");
		}//end test
		
		/**Test reversal with books, by adding a book, reversing and reversing again**/
		@Test
		public void testReversalOfBooks() {
			r3.add(n4);//Add to reversed list (high to low)
			r3.reverse();//Put in low to high order
			r3.reverse();//put high to low order gain
			
			Novel novel1 = r3.get(0);
			Novel novel2 = r3.get(1);
			Novel novel3 = r3.get(2);
			Novel novel4 = r3.get(3);
			
			boolean check1 = novel1.equals(n4);//harper lee, 1960, to kill a mocking bird
			boolean check2 = novel2.equals(n1);//george orwell, 1949, 1984
			boolean check3 = novel3.equals(n2);//charles dickens, 1859,tale of 2 cities
			boolean check4 = novel4.equals(n3);//Angie Thomas,Concrete Rose, 2021
		
			assertTrue(check1 && check2&& check3 && check4, 
					"The order off the books is high to low");
		}//end test
	}//end testReversedSet

	
}//end testSuite
