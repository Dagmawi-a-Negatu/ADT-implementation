package tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/*
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
*/



import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import myadt.ASet;
import myadt.LSet;
import myadt.SetInterface;


@DisplayName("Interoperability tests to check for compatibility of ASet and LSet")
public class InteropTests {
	
	
	/**A nested test suite for testing the interoperability of the ASet and the LSet.**/
	@Nested
	@DisplayName("Test the interoperability of ASet with an LSet")
	public class testASetInteroprabilityWithLSet{
		
		/**Test that an ASet can be constructed using an LSet**/
		@Test
		public void constructAnASetWithAnLSet() {
			SetInterface<String> tls = new LSet<>(false);
			tls.add("Alpha");
			tls.add("Delta");
			tls.add("Beta");
			SetInterface<String> tas = new ASet<>(tls,false);	
				
			assertEquals( 3, tas.size(), "An ASet constructor can receive an LSet, size should be 3");
			
			assertTrue(	tas.get(0).equals("Alpha") && 
					    tas.get(1).equals("Beta")  && 
					    tas.get(2).equals("Delta"), 
					    "The ASet is constructed with the values <\"Alpha\", \"Beta\", \"Delta\">" );
		}//end test
		
		/**Test that an ASet can be constructed using an LSet**/
		@Test
		public void testAddAdll() {
			SetInterface<String> tls = new LSet<>(false);
			tls.add("Alpha");
			tls.add("Delta");
			tls.add("Beta");
			SetInterface<String> tas = new ASet<>();
			tas.addAll(tls);
			
			assertEquals( 3, tas.size(),"An AS  can addAll with an LSet, size should be 3");
			assertTrue(tas.get(0).equals("Alpha") &&  
					    tas.get(1).equals("Beta") &&  
					    tas.get(2).equals("Delta"),
					"The ASet has  added the values <\"Alpha\", \"Beta\", \"Delta\">" );
		}//end test
		
		
		/**Test that equals on an ASet can receive an LSet and just work.**/
		@Test
		public void testEquals() {
			SetInterface<String> tls = new LSet<>(false);
			tls.add("Alpha");
			tls.add("Delta");
			tls.add("Beta");
			
			SetInterface<String> tas = new ASet<>(false);
			tas.add("Alpha");
			tas.add("Delta");
			tas.add("Beta");	
			System.out.println(tas.toString());
			System.out.println(tls.toString());
			assertTrue( tas.equals(tls), "An ASet and LSet with the same elemments is equal");
		}//end test
		
		
		/**Test that containsAll on an ASet can receive an LSet and just work.**/
		@Test
		public void testContainsAll() {
			SetInterface<String> tls = new LSet<>(false);
			tls.add("Alpha");
			tls.add("Delta");
			tls.add("Beta");
			
			SetInterface<String> tas = new ASet<>(false);
			tas.add("Alpha");
			tas.add("Delta");
			tas.add("Beta");
			
			assertTrue(  tas.containsAll(tls),"An ASet and LSet with the same elemments containsAll is true");
		}//end test
		
		/**Test that removeAll on an ASet can receive an LSet and just work.**/
		@Test 
		public void testRemoveAll() {
			SetInterface<String> tls = new LSet<>(false);
			tls.add("Alpha");
			tls.add("Delta");
			tls.add("Beta");
			
			SetInterface<String> tas = new ASet<>(false);
			tas.add("Alpha");
			tas.add("Delta");
			tas.add("Beta");
			
			tas.removeAll(tls);
			System.out.println(tas.toString());
			
			assertEquals( 0, tas.size(),"An ASet and LSet with the same elemments, remove all clears list");
		}//end test
		
		/**Test that retainAll on an ASet can receive an LSet and just work.**/
		@Test
		public void testRetainAll(){
			SetInterface<String> tls = new LSet<>(false);
			tls.add("Alpha");
			tls.add("Beta");
			
			SetInterface<String> tas = new ASet<>(false);
			tas.add("Alpha");
			tas.add("Delta");
			tas.add("Beta");
			
			tas.retainAll(tls); 
			assertEquals( 2, tas.size(),"Test retain all with similar ASet and LSet, size should be two");
		}//end test
		
	}//end test suite
	
	
	
	/**A nested test suite for testing the interoperability of the ASet and the LSet.**/
	@Nested
	@DisplayName("Test the interoperability of ASet with an LSet")
	public class testLSetInteroprabilityWithASet{
		
		/**Test that an LSet can be constructed using an ASet**/
		@Test
		public void constructAnASetWithAnLSet() {
			SetInterface<String> tls = new ASet<>(false);
			tls.add("Alpha");
			tls.add("Delta");
			tls.add("Beta");
			SetInterface<String> tas = new LSet<String>(tls,false);	
				
			assertEquals( 3, tas.size(), "An LSet constructor can receive an ASet, size should be 3");
			assertTrue(	tas.get(0).equals("Alpha") &&  
					     tas.get(1).equals("Beta") &&  
					     tas.get(2).equals("Delta") ,
					     "The LSet is constructed with the values <\"Alpha\", \"Beta\", \"Delta\"> from an ASet");
		}//end test
		
		/**Test that an LSet can be constructed using an ASet**/
		@Test
		public void testAddAdll() {
			SetInterface<String> tls = new ASet<>(false);
			tls.add("Alpha");
			tls.add("Delta");
			tls.add("Beta");
			SetInterface<String> tas = new LSet<>();
			tas.addAll(tls);
			
			assertEquals( 3, tas.size(), "An LSet  can addAll with an ASet, size should be 3");
			assertTrue( tas.get(0).equals("Alpha") &&  
					    tas.get(1).equals("Beta") && 
					    tas.get(2).equals("Delta"), 
					    "The LSet has added the values <\"Alpha\", \"Beta\", \"Delta\"> from an ASet" );
		}//end test
		
		
		/**Test that equals on an LSet can receive an ASet and just work.**/
		@Test
		public void testEquals() {
			SetInterface<String> tls = new ASet<>(false);
			tls.add("Alpha");
			tls.add("Delta");
			tls.add("Beta");
			
			SetInterface<String> tas = new LSet<>(false);
			tas.add("Alpha");
			tas.add("Delta");
			tas.add("Beta");		
			assertTrue(  tas.equals(tls), "An LSet and ASet with the same elemments is equal");
		}//end test
		
		
		/**Test that containsAll on an LSet can receive an ASet and just work.**/
		@Test
		public void testContainsAll() {
			SetInterface<String> tls = new ASet<>(false);
			tls.add("Alpha");
			tls.add("Delta");
			tls.add("Beta");
			
			SetInterface<String> tas = new LSet<>(false);
			tas.add("Alpha");
			tas.add("Delta");
			tas.add("Beta");
			
			assertTrue(  tas.containsAll(tls),"An LSet and ASet with the same elemments containsAll is true");
		}//end test
		
		/**Test that removeAll on an LSet can receive an ASet and just work.**/
		@Test 
		public void testRemoveAll() {
			SetInterface<String> tls = new ASet<>(false);
			tls.add("Alpha");
			tls.add("Delta");
			tls.add("Beta");
			
			SetInterface<String> tas = new LSet<>(false);
			tas.add("Alpha");
			tas.add("Delta");
			tas.add("Beta");
			
			tas.removeAll(tls);
			assertEquals( 0, tas.size(), "An LSet and ASet with the same elemments, remove all clears list");
		}//end test
		
		/**Test that retainAll on an LSet can receive an ASet and just work.**/
		@Test
		public void testRetainAll(){
			SetInterface<String> tls = new ASet<>(false);
			tls.add("Alpha");
			tls.add("Beta");
			
			SetInterface<String> tas = new LSet<>(false);
			tas.add("Alpha");
			tas.add("Delta");
			tas.add("Beta");
			
			tas.retainAll(tls);
			assertEquals( 2, tas.size(), "Test retain all with similar LSet and ASet, size should be two");
		}//end test
		
	}//end test suite
	
	
	
	

}//end class
